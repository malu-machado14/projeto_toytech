#import

from core.conexao import Database
from core.validar import Validador
#classe que representa uma localizacao
class Localizacao:
    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, rua=None, prateleira=None, andar=None, id=None):
        #atribui os valores aos objetos
        self.id = id
        self.rua = rua
        self.prateleira = prateleira
        self.andar = andar

    #cadastro da localizacao
    def insert(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO localizacao
        (rua, prateleira, andar)
        VALUES (%s, %s, %s)
        """
        valores = (
            self.rua,
            self.prateleira,
            self.andar,
            
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()
    
    #valida os dados da localizacao
    def validate(self):

        #lista de possiveis erros
        erros = [
             Validador.non_negative(self.rua, "rua"),
             Validador.non_negative(self.prateleira, "prateleira"),
             Validador.non_negative(self.andar, "andar"),
            ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #metodo para listar localizacao
    @staticmethod
    def find_all():
        #conexao com o banco
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM localizacao ORDER BY rua"
        cursor.execute(sql)
        Localizacao = cursor.fetchall()

        cursor.close()
        conexao.close()
        return Localizacao
    
    #metodo para buscar o id da localizacao
    @staticmethod
    def find_by_id(id):
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM localizacao WHERE id = %s"
        cursor.execute(sql, (id,))
        Localizacao = cursor.fetchone()

        cursor.close()
        conexao.close()
        return Localizacao

    #metodo para atualizar localizacao
    def update(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        UPDATE localizacao
        SET rua = %s,
            prateleira = %s,
            andar = %s
        WHERE id = %s
        """
        valores = (
            self.rua,
            self.prateleira,
            self.andar,
            self.id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #metodo para excluir localizacao
    @staticmethod
    def delete(id):
        conexao = Database()
        cursor = conexao.cursor()

        sql = "DELETE FROM localizacao WHERE id = %s"
        cursor.execute(sql, (id,))
        conexao.commit()

        cursor.close()
        conexao.close()

