#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa um sensor no sistema
class Sensor(Crud):
    table = "sensor"
    #lista de campos da tabela
    fields = [
        "id"
        "modelo_sensor",
        "descricao_funcao_sensor",
        "descricao_base",
        "altura_sensor",
        "largura_sensor",
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, modelo_sensor, descricao_base, descricao_funcao_sensor, altura_sensor,
                 largura_sensor):
        #atribui os valores aos objetos
        self.modelo_sensor = modelo_sensor
        self.descricao_base = descricao_base
        self.descricao_funcao_sensor = descricao_funcao_sensor
        self.altura_sensor = altura_sensor
        self.largura_sensor = largura_sensor

    #cadastro do sensor
    def insert(self):
        conexao = Database()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO sensor
        (modelo_sensor, descricao_base, descricao_funcao_sensor, altura_sensor, largura_sensor)
        VALUES (%s, %s, %s, %s, %s)
        """
        valores = (
            self.modelo_sensor,
            self.descricao_base,
            self.descricao_funcao_sensor,
            self.altura_sensor,
            self.largura_sensor,
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #valida os dados do produto
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.modelo_sensor, "modelo do sensor"),
         Validador.non_negative(self.descricao_base, "descrição base do sensor no geral"),
         Validador.non_negative(self.descricao_funcao_sensor, "descrição das funções do sensor"),
         Validador.non_negative(self.altura_sensor, "altura do sensor"),
         Validador.non_negative(self.largura_sensor, "largura do sensor")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #retorna sensores em ordem alfabetica
    @classmethod
    def find_by_name(cls):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM sensor ORDER BY nome"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @staticmethod
    def find_by_id(id):
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM sensor WHERE id = %s"
        cursor.execute(sql, (id,))
        Fornecedor = cursor.fetchone()

        cursor.close()
        conexao.close()
        return Fornecedor        

    #metodo para atualizar a quantidade de sensor
    @classmethod
    def update(cls, id, novo_modelo, nova_descricao_base, nova_descricao_funcao,nova_altura,nova_largura, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE solicitador SET modelo_sensor = %s, descricao_base = %s, descricao_funcao_sensor = %s, altura_sensor = %s, largura_sensor = %s WHERE id = %s"
            cursor.execute(sql, (novo_modelo,nova_descricao_base,nova_descricao_funcao,nova_altura,nova_largura, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    #metodo para deletar um sensor
    @classmethod
    def delete(cls, id):
        Sensor = cls.find_by_id(id)
        if not Sensor:
            raise ValueError("Sensor não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o sensor.")
        cls.delete(id)
