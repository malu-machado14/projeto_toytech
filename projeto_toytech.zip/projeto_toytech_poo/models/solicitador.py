#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa um solicitador no sistema
class Solicitador(Crud):
    table = "solicitador"
    #lista de campos da tabela
    fields = [
        "id",
        "nome",
        "cnpj",
        "senha",
        "telefone",
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, cnpj, senha, telefone,):
        #atribui os valores aos objetos
        self.nome = nome
        self.cnpj = cnpj
        self.senha = senha
        self.telefone = telefone

    #valida os dados do produto
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.nome, "nome"),
         Validador.non_negative(self.cnpj, "cnpj"),
         Validador.non_negative(self.senha, "senha"),
         Validador.non_negative(self.telefone, "telefone")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #retorna solicitadores em ordem alfabetica
    @classmethod
    def find_by_name(cls):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM solicitador ORDER BY nome"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @staticmethod
    def find_all():
        #conexao com o banco
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM solicitador ORDER BY nome"
        cursor.execute(sql)
        Solicitador = cursor.fetchall()

        cursor.close()
        conexao.close()
        return Solicitador

    #metodo para buscar o id de funcionario
    @staticmethod
    def find_by_id(id):
        conexao = Database()
        cursor = conexao.cursor(dictionary=True)

        sql = "SELECT * FROM solicitador WHERE id = %s"
        cursor.execute(sql, (id,))
        Solicitador = cursor.fetchone()

        cursor.close()
        conexao.close()
        return Solicitador        

        

    #metodo para atualizar a quantidade de solicitadores
    @classmethod
    def update(cls, id, novo_nome, nova_senha, novo_telefone, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE solicitador SET nome = %s, senha = %s, telefone = %s WHERE id = %s"
            cursor.execute(sql, (novo_nome,nova_senha,novo_telefone, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    #metodo para deletar um solicitador
    @classmethod
    def delete(cls, id):
        Solicitador = cls.find_by_id(id)
        if not Solicitador:
            raise ValueError("Solicitador não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o solicitador.")
        cls.delete(id)
