#Bloco de importações de componentes para o funcionamento do back-end

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import mysql.connector
from models.produto import Produto
from models.fornecedor import Fornecedor
from models.funcionario import Funcionario
from models.notificacao import Notificacao
from models.sensor import Sensor
from models.localizacao import Localizacao
from models.solicitador import Solicitador
from models.solicitacao_entrada import SolicitacaoEntrada
from models.solicitacao_saida import SolicitacaoSaida
from models.item_solicitacao_entrada import ItemSolicitacaoEntrada
from models.item_solicitacao_saida import ItemSolicitacaoSaida
from models.estoque import Estoque
from datetime import date

#inicialização
app = Flask(__name__)
app.secret_key = "chave_secreta"

#inicialização das notificações do sistema
def adicionar_notificacao(mensagem, categoria="sucesso"):
    notificacoes = session.get("notificacoes", [])

    notificacoes.append({
        "mensagem": mensagem,
        "categoria": categoria
    })

    session["notificacoes"] = notificacoes

'''defs detalhamento de campos do get_form (são detalhamentos para especificar 
  o tipo de dado que será armazenado em cada campo do formulário.)'''

def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=0.0):
    try: 
        return float(value)
    except (TypeError, ValueError):
        return default

def to_tel(value, default=''):
    try:
        return str(value)
    except (TypeError, ValueError):
        return default

# captação de dados inseridos nos formulários das telas de front-end, sendo essenciais para os endpoints fazerem 
# suas devidas funções

def get_produto_form():
    return {
        "id": to_int(request.form.get("id", "").strip()),
        "nome": request.form.get("nome", "").strip(),
        "descricao": str(request.form.get("descricao", "").strip()),
        "localizacao_produto": to_int(request.form.get("localizacao_produto", "").strip()),
        "fornecedor_id": to_int(request.form.get("fornecedor_id", "").strip()),
        "imagem_nome": str(request.form.get("imagem_nome","").strip()),
        "imagem_tipo": str(request.form.get("imagem_tipo","").strip()),
        "imagem_blob": request.form.get("imagem_blob","").strip(),
        "preco": to_float(request.form.get("preco",0))
    }
def get_fornecedor_form():
    return {
        "id": to_int(request.form.get("id", "").strip()),
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone": to_tel(request.form.get("telefone","").strip())
    }

def get_funcionario_form():
    return {
        "id": to_int(request.form.get("id", "").strip()),
        "nome": request.form.get("nome", "").strip(),
        "cpf": request.form.get("cpf", "").strip(),
        "telefone": to_tel(request.form.get("telefone","").strip()),
        "email": request.form.get("email", "").strip(),
        "senha": request.form.get("senha","").strip(),
        "cargo": request.form.get("cargo","").strip()
    }


def get_solicitador_form():
    return {
        "id": to_int(request.form.get("id", "").strip()),
        "nome": request.form.get("nome", "").strip(),
        "cnpj": request.form.get("cnpj", "").strip(),
        "telefone":to_tel(request.form.get("telefone","").strip()),
        "senha": request.form.get("senha","").strip(),
    }

def get_sensor_form():
    return {
        "id": to_int(request.form.get("id","").strip()),
        "modelo_sensor": request.form.get("modelo_sensor", "").strip(),
        "descricao_funcao_sensor": request.form.get("descricao_funcao_sensor", "").strip(),
        "fornecedor_id": to_int(request.form.get("fornecedor_id","").strip()),
        "altura_sensor": request.form.get("altura_sensor", "").strip(),
        "largura_sensor": request.form.get("largura_sensor", "").strip(),
        "tipo": request.form.get("tipo","").strip(),    
    }

def get_localizacao_form():
    return {
        "id": to_int(request.form.get("id", "").strip()),
        "prateleira": request.form.get("prateleira", "").strip(),
        "andar": request.form.get("andar","").strip(),
        "rua": request.form.get("rua","").strip()
    }

def get_solicitacao_entrada_form():
    return {
        "id_operacao_e": to_int(request.form.get("id_operacao_e", "").strip()),
        "data_solicitacao_entrada": request.form.get("data_solicitacao_entrada", "").strip(),
        "funcionario_id": to_int(request.form.get("funcionario_id","").strip()),
        "fornecedor_id": to_int(request.form.get("fornecedor_id","").strip()),
        "observacao": str(request.form.get("observacao","").strip())
        }

def get_estoque_form():
    return{
        "estoque_id": to_int(request.form.get("estoque_id","").strip()),
        "produto_id": to_int(request.form.get("produto_id","").strip()),
        "produto_quantidade": to_int(request.form.get("produto_quantidade", "").strip())
    }

def get_item_solicitacao_entrada_form():
    return {
        "id_item_e": to_int(request.form.get("id_item_e", "").strip()),
        "id_operacao_e": to_int(request.form.get("id_operacao_e", "").strip()),
        "estoque_id": to_int(request.form.get("estoque_id","").strip())
    }

def get_solicitacao_saida_form():
    return {
        "id_operacao_s": to_int(request.form.get("id_operacao_s", "").strip()),
        "data_solicitacao_saida": request.form.get("data_solicitacao_saida", "").strip(),
        "observacao": request.form.get("observacao","").strip(),
        "funcionario_id": to_int(request.form.get("funcionario_id","").strip()),
        "solicitador_id": to_int(request.form.get("solicitador_id","").strip())
    }

def get_item_solicitacao_saida_form():
    return {
        "id_item_s": to_int(request.form.get("id_item_s", "").strip()),
        "id_operacao_s": to_int(request.form.get("id_operacao_s", "").strip()),
        "estoque_id": to_int(request.form.get("estoque_id","").strip())
    }

#configuração dos tipos de imagem específicas que o sistema suporta para o cadastro e atualização do produto
EXTENSOES_PERMITIDAS = {"image/png", "image/jpeg", "image/jpg", "image/webp","image/jfif","image/heic","image/heif"}

#permissão do uso dos tipos de imagem configurados anteriormente para o tipo_arquivo da imagem
def imagem_permitida(tipo_arquivo):
    return tipo_arquivo in EXTENSOES_PERMITIDAS

#rota inicial do sistema
@app.route("/")
def inicial():
    return render_template("index.html") #tela inicial que abre o sistema

#rota de login do usuário
@app.route("/login", methods=["POST","GET"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        senha = request.form.get("senha")
        try:
            funcionario_dados = Funcionario.find_by_email(email)

            if funcionario_dados and funcionario_dados["senha"] == senha:
                session["funcionario_id"] = funcionario_dados["id"]
                session["funcionario_nome"] = funcionario_dados["nome"]
                session["funcionario_cargo"] = funcionario_dados["cargo"]
                Notificacao.create(
                    funcionario_dados["id"],
                    "Login realizado",
                    f"{funcionario_dados['nome']} entrou no sistema.",
                    "login"
                )
                flash("Login realizado com sucesso!", "success")
                return redirect(url_for("dashboard"))
            else:
                flash("Email ou senha inválidos", "danger")
                return render_template("loginbs.html")
        except Exception as e:
            flash(f"erro ao tentar fazer login: {e}", "erro")
            return render_template("loginbs.html")
    return render_template("loginbs.html")

#rota de logout do usuário
@app.route("/logout")
def logout():
    funcionario_id = session.get("funcionario_id")
    funcionario_nome = session.get("funcionario_nome")
    #registra o logout se houver funcionário logado
    if funcionario_id:
        Notificacao.create(
            funcionario_id,
            "Logout realizado",
            f"{funcionario_nome} saiu do sistema.",
            "logout"
        )
    session.clear()
    flash("Você saiu do sistema.", "info")
    return redirect(url_for("inicial"))

#rota que abre a tela de carregamento da tela de cadastro, sendo a rota inicial da tela de cadastro
@app.route("/cadastro") 
def cadastro():
    return render_template("cadastro.html")

#rota de cadastro do usuário antes de sua entrada no sistema
@app.route("/cadastro/salvar", methods=["POST"])
def cadastro_salvar():
    #captura de dados
    dados = get_funcionario_form()
    funcionario = Funcionario(**dados)
    #aviso em caso de erros na digitação dos dados para o cadastro
    erros = funcionario.validate()
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("cadastro.html", funcionario=dados)
    try:
        #conexão com a função de insert no model de funcionario, cadastrando um novo funcionario com os dados inseridos
        funcionario.insert()
        #mensagem de sucesso e redirecionamento ao login
        flash("Cadastro realizado com sucesso! Agora faça seu login.", "sucesso")
        return render_template("cadastro.html", cadastro_sucesso=True)
        #mensagem de erro e redirecionamento ao cadastro de novo usuario, para fazer o cadastro novamente
    except Exception as e:
        flash(f"Erro ao realizar cadastro: {e}", "erro")
        return render_template("cadastro.html", funcionario=dados)

#rota definida para quando houver um erro de página não encontrada o usuário ser redirecionado 
# para a tela de erro, avisando sobre o erro 404 e um detalhamento sobre aquele erro 
@app.errorhandler(404)
def pagina_nao_encontrada(error):
    return render_template("404.html"), 404

#rota que abre o dashboard em funcionamento (sendo também responsável pelo funcionamento do 
# gráfico de quantidade de cada produto no estoque que está no dashboard)
@app.route("/dashboard")
def dashboard():
    dados_dashboard = Estoque.find_produto_qtd()
    total = 0
    for i in dados_dashboard:
        total += i['qtd']
    return render_template("dashboard.html", dados = dados_dashboard, total = total)

@app.route("/produto/buscar/id", methods = ["POST"]) # endpoint usado para capturar dados da tela de mov saída
def get_produto_id():
    id = request.get_json()
    produto = Produto.find_by_id(id['value']) #variavel produto acessa a classe Produto e usa a def de encontrar por id e define como value - parametro usado no script
    if not produto:
        return("Produto não encontrado.", "erro")
    else:
        result = {"nome" :produto.nome, "preco": produto.preco} #pega o nome e o preco do id correspondente
        return jsonify(result = result),201 #retorna como jsonify e manda para o script do mov_solicitacao_saida


#rota da tela inicial de produtos (que já lista todos os produtos sem qualquer filtro)
@app.route("/produto/listar")
def listar_produto():
    return render_template("lista_produto.html", produtos=Produto.find_all())

#rota da listagem dos produtos na tela inicial de produto (filtrada por nome)
@app.route("/produto/listar/nome/<string:nome>")
def listar_produto_name(nome):
    return render_template("lista_produto.html", produtos=Produto.find_by_name(nome))

#rota da listagem dos produtos na tela inicial de produto (filtrada por preço de venda)
@app.route("/produto/listar/preco/<float:preco>", methods = ["GET"])
def listar_produto_preco(preco):
    #conexão com a rota de listagem de produtos pelo preço no model de Produto
    produto = Produto.find_by_price(preco)
    #mensagem de erro e redirecionamento a tela de listagem de produto geral 
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("listar_produto"))
    #redirecionamento a tela de listagem de produto geral, ocorre apenas quando há sucesso na listagem
    return render_template("lista_produto.html", produto=produto)

#rota definida para ao finalizar um cadastro ou atualização, o usuário ser redirecionado para a tela de listagem geral do produto 
@app.route("/produto/novo", methods = ["GET"])
def novo_produto():
    return render_template("produto.html", produto=None)

#rota do campo de buscar os produtos diretamente (filtrado por nome também, já que quando o usuário digita e clica em buscar
#o produto escrito ele encontra e lista ao usuário)
@app.route("/produto/buscar", methods=["GET"])
def buscar_produto():
    #request pelo campo nome
    nome = request.args.get("nome", "")
    #se nome for igual a nada, o usuário é redirecionado a tela inicial de listagem geral
    if nome.strip() == "": 
        return redirect(url_for("listar_produto"))
    #conexão da rota com a função de listagem filtrada por nome do model de produto
    produtos = Produto.find_by_name(nome)
    #rederização da tela de listagem de produto geral pós busca específica
    return render_template(
        "lista_produto.html",
        produtos=produtos
    )

#rota necessária para a edição direta dos produtos
@app.route("/produto/editar/<int:id>", methods=["GET"])
def editar_produto(id):
    produto = Produto.find_by_id(id)
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("listar_produto"))
    return render_template("produto.html", produto=produto)

#rota de cadastro de produto
@app.route("/produto/salvar", methods=["POST"])
def salvar_produto():
    #definições iniciais do campo de imagem, para a captação dos dados necessários dessa imagem 
    arquivo = request.files.get("imagem")

    imagem_nome = None
    imagem_tipo = None
    imagem_blob = None

    #caso a imagem não esteja compatível aos requerimentos do sistema
    if arquivo and arquivo.filename != "":
        if not imagem_permitida(arquivo.content_type):
            flash("Formato de imagem inválido. Use PNG, JPG, JPEG ou WEBP.", "danger")
            return redirect(url_for("novo_produto"))

        imagem_nome = arquivo.filename
        imagem_tipo = arquivo.content_type
        imagem_blob = arquivo.read()

    #assimilação dos dados que foram digitados e inseridos no formulário para esses campos de imagem, e então serem validados
    dados = get_produto_form()
    dados["imagem_nome"] = imagem_nome
    dados["imagem_tipo"] = imagem_tipo
    dados["imagem_blob"] = imagem_blob
    produto = Produto(**dados)

    #caminho do erro, ao qual em caso de erro na definição de imagem, o erro é comunicado e o usuário é 
    # redirecionado a tela inicial do cadastro do produto
    erros = produto.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("produto.html", produto=dados)

    #cadastro dos dados inseridos 
    try:
        produto_id = produto.insert()
        #definição dos campos do estoque pós cadastro de um novo produto, para estar hábil as movimentações
        valores = {"estoque_id":0,"produto_id": produto_id, "produto_quantidade": 0} 
        estoque = Estoque(**valores)
        print("ESTOQUE",estoque.produto_id, estoque.produto_quantidade)
        estoque.insert()
        #criação da notificação de que um funcionário adicionou um novo produto, detalhando o nome do funcionário que adicionou o produto e qual o produto novo
        Notificacao.create(
            session["funcionario_id"],
            "Novo produto",
            f"{session['funcionario_nome']} cadastrou o produto {produto.nome}.",
            "produto"
        )
        flash("Produto cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_produto"))    
    #caminho de erro no cadastro, avisando que houve um erro no cadastro, redirecionando o usuário de volta a tela do cadastro 
    except Exception as e:
        flash(f"Erro ao cadastrar produto: {e}", "erro")
        return render_template("produto.html", produto=dados)

#listagem dos produtos filtrada pelo id, listando apenas o produto com id = 1,2,3...etc 
@app.route("/produto/listar/id/<int:id>", methods = ["GET"])
def listar_produto_id(id):
    #conexão com a listagem de produto por id no model de produto
    produto = Produto.find_by_id(id)
    #mensagem de erro e redirecionamento do usuário a listagem de produtos geral
    if not produto:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("listar_produto"))
    #redirecionamento a tela de listagem com a listagem por id específica
    return render_template("lista_produto.html", produto=produto)


@app.route("/produto/atualizar/<int:id>", methods=["POST"])
def atualizar_produto(id):

    #encontra o produto atual que será atualizado, conectando-se com a listagem de produto por id no model de produto
    produto_atual = Produto.find_by_id(id)
    #mensagem de erro e redirecionamento a tela de listagem geral
    if not produto_atual:
        flash("Produto não encontrado.", "erro")
        return redirect(url_for("listar_produto"))
    #request dos arquivos inseridos no campo de imagem
    arquivo = request.files.get("imagem")

    #obtenção dos dados inseridos no formulário
    dados = get_produto_form()

    dados["id"] = id

    dados["fornecedor_id"] = to_int(
        request.form.get("fornecedor_id")
    )

    dados["localizacao_produto"] = to_int(
        request.form.get("localizacao_produto")
    )

    #mensagem de erro na obtenção dos dados da imagem e redirecionamento para a tela de atualização, para uma nova execução

    if arquivo and arquivo.filename != "":

        if not imagem_permitida(arquivo.content_type):

            flash(
                "Formato de imagem inválido. Use PNG, JPG, JPEG ou WEBP.",
                "erro"
            )

            return render_template(
                "produto.html",
                produto=dados
            )

        #salva a nova imagem inserida nos campos para ser gravada posteriormente
        dados["imagem_nome"] = arquivo.filename
        dados["imagem_tipo"] = arquivo.content_type
        dados["imagem_blob"] = arquivo.read()

    else:

        #mantém a imagem antiga em caso de não alteração na imagem do produto
        dados["imagem_nome"] = produto_atual.imagem_nome
        dados["imagem_tipo"] = produto_atual.imagem_tipo
        dados["imagem_blob"] = produto_atual.imagem_blob

    #validação dos dados que foram inseridos nos campos

    produto = Produto(**dados)

    erros = produto.validate()
    #mensagem de erro e redirecionamento a tela de atualização do produto
    if erros:

        for erro in erros:
            flash(erro, "erro")

        return render_template(
            "produto.html",
            produto=produto
        )

    #operação feita para dar o reset na imagem 
    try:
        imagem_nome = None
        imagem_tipo = None
        imagem_blob = None

        if arquivo and arquivo.filename != "":
            #mensagem de erro e redirecionamento para a tela de atualização de produtos
            if not imagem_permitida(arquivo.content_type):
                flash("Formato de imagem inválido. Use PNG, JPG, JPEG ou WEBP.", "erro")
                return render_template("produto.html", produto=produto_atual)
            #grava a nova imgem no banco, salva anteriormente no campo
            imagem_nome = arquivo.filename
            imagem_tipo = arquivo.content_type
            imagem_blob = arquivo.read()

        #atualização de todos os dados atualizados no banco
        Produto.update(
            nome=dados["nome"],
            descricao=dados["descricao"],
            preco=dados["preco"],
            id=id,
            imagem_nome=dados["imagem_nome"],
            imagem_tipo=dados["imagem_tipo"],
            imagem_blob=dados["imagem_blob"] if arquivo and arquivo.filename else None
        )
        #criação da notificação da atualização, mostrando que a atualização foi um sucesso e quem a fez e em qual produto foi feito
        Notificacao.create(
            session["funcionario_id"],
            "Produto editado",
            f"{session['funcionario_nome']} editou o produto {produto.nome}.",
            "produto" )

        flash(
            "Produto atualizado com sucesso.",
            "sucesso"
        )
        #redirecionamento para a listagem do produto
        return redirect(
            url_for("listar_produto")
        )
    #caminho de erro, redirecionando novamente para a tela de atualização do produto
    except Exception as e:

        flash(
            f"Erro ao atualizar produto: {e}",
            "erro"
        )

        return render_template(
            "produto.html",
            produto=produto
        )

@app.route("/produto/excluir/<int:id>", methods=["POST"])
def excluir_produto(id):
    #Exclusão do produto, encontrando o produto que será excluído pelo id digitado
    try:
        produto = Produto.find_by_id(id)
        Produto.delete(id)
        #notificação sobre a exclusão sucedida do produto e a quem fez a exclusão de qual produto
        try:
            Notificacao.create(
                session["funcionario_id"],
                "Produto excluído",
                f"{session['funcionario_nome']} excluiu o produto {produto.nome}.",
                "produto"
            )
        #erro da notificação de exclusão
        except Exception as e:
            print("ERRO NA NOTIFICAÇÃO:", e)
        #mensagem de sucesso na operação e redirecionamento a listagem de produtos geral
        flash("Produto excluído com sucesso.", "sucesso")
        return redirect(url_for("listar_produto"))
    #redirecionamentos para a listagem de produto em caso de erros
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_produto"))

    except mysql.connector.Error as erro:
        if erro.errno == 1451:
            flash(
                "Produto não pode ser excluído. "
                "Este produto está vinculado a uma ou mais movimentações de estoque.",
                "erro"
            )
        else:
            flash(
                "Não foi possível excluir o produto. Tente novamente.",
                "erro"
            )

        return redirect(url_for("listar_produto"))

    except Exception as e:
        print("ERRO AO EXCLUIR PRODUTO:", e)
        flash(
            "Não foi possível excluir o produto. Tente novamente.",
            "erro"
        )
        return redirect(url_for("listar_produto"))
    
@app.route("/sensor/lista")
#listagem de sensores geral
def listar_sensor():
    return render_template("lista_sensor.html", sensor=Sensor.find_all())

@app.route("/sensor/lista/modelo/<string:modelo_sensor>")
#listagem de sensores (filtrado pelo modelo digitado)
def listar_sensor_modelo(modelo_sensor):
    return render_template("lista_sensor.html", sensor=Sensor.find_by_name(modelo_sensor))

@app.route("/sensor/buscar", methods=["GET"])
#busca de sensores específicos pelo modelo
def buscar_sensor():
    modelo_sensor = request.args.get("modelo_sensor", "")
    #redirecionamento do usuário para a listagem geral do sensor em caso de campo de busca == a nada
    if modelo_sensor.strip() == "":
        return redirect(url_for("listar_sensor"))
    #busca do sensor pelo nome digitado no campo de busca
    sensor = Sensor.find_by_name(modelo_sensor)
    #redirecionamento do usuário a listagem de sensor
    return render_template(
        "lista_sensor.html",
        sensor=sensor
    )

@app.route("/sensor/novo", methods = ["GET"])
#renderização da tela de cadastro de sensores
def novo_sensor():
    return render_template("sensor.html", sensor=None)

#rota necessária para a edição direta dos sensores
@app.route("/sensor/editar/<int:id>", methods=["GET"])
def editar_sensor(id):
    sensor = Sensor.find_by_id(id)
    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("listar_sensor"))
    return render_template("sensor.html", sensor=sensor)

@app.route("/sensor/salvar", methods=["POST"])
#cadastro do sensor
def salvar_sensor():
    dados = get_sensor_form()
    sensor = Sensor(**dados)
    erros = sensor.validate()
#mensagem de erro e redirecionamento ao cadastro de sensor novamente
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("sensor.html", sensor=dados)

    try:
        sensor.insert()
        #notificação sobre quem adicionou o sensor e o sensor adicionado e se o cadastro foi sucedido
        Notificacao.create(
            session["funcionario_id"],
            "Novo sensor",
            f"{session['funcionario_nome']} cadastrou o sensor {sensor.modelo_sensor}.",
            "sensor"
        )
        flash("O sensor foi cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_sensor"))
        #erro ao cadastrar sensor
    except Exception as e:
        flash(f"Erro ao cadastrar o sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)

@app.route("/sensor/lista/id/<int:id>", methods = ["GET"])
def listar_sensor_id(id):
    #listagem dos sensores pelo id digitado
    sensor = Sensor.find_by_id(id)
    #mensagem de erro em caso do id não existir / estar errado
    if not sensor:
        flash("Sensor não encontrado.", "erro")
        return redirect(url_for("listar_sensor"))
    #redirecionamento a listagem de de sensores com o produto em específico a mostra
    return render_template("lista_sensor.html", sensor=sensor)

@app.route("/sensor/atualizar/<int:id>", methods=["POST"])
#definiciçãi dos dados de cada campo antes da atualização de dados do sensor
def atualizar_sensor(id):
    dados = get_sensor_form()
    dados["id"] = id
    dados["fornecedor_id"] = to_int(request.form.get("fornecedor_id"))
    #validação dos campos
    sensor = Sensor(**dados)
    erros = sensor.validate()
    #mensagem de erro e redirecionamento a tela de atualização de produtos novamente
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("sensor.html", sensor=dados)
    #a rota faz uma nova busca com o id para encontrar o produto para a atualização, em caso de erro ele redireciona o usuário a listagem de sensores, em caso de sucesso a rota continua
    try:
        if not Sensor.find_by_id(id):
            flash("Sensor não encontrado.", "erro")
            return redirect(url_for("listar_sensor"))
        #atualização dos dados do sensor
        sensor.update(
        dados["modelo_sensor"], 
        dados["descricao_funcao_sensor"], 
        dados["fornecedor_id"],
        dados["altura_sensor"], 
        dados["largura_sensor"], 
        dados["tipo"],id)
        #Notificação de atualização do sensor, quem atualizou, qual produto atualizou e se deu sucesso
        Notificacao.create(
            session["funcionario_id"],
            "Sensor editado",
            f"{session['funcionario_nome']} editou o sensor {dados['modelo_sensor']}.",
            "sensor"
        )
        flash("Sensor atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_sensor"))
    #mensagem de erro e redirecionamento a tela de atualização do sensor
    except Exception as e:
        flash(f"Erro ao atualizar sensor: {e}", "erro")
        return render_template("sensor.html", sensor=dados)

@app.route("/sensor/excluir/<int:id>", methods = ["POST"])
def excluir_sensor(id):
    #rota de exclusão do sensor
    try:
        Sensor.delete(id)
        Notificacao.create(
            session["funcionario_id"],
            "Sensor excluído",
            f"{session['funcionario_nome']} excluiu o sensor {session['modelo_sensor']}.",
            "sensor"
        )
        flash("Sensor foi excluído com sucesso.", "sucesso")
        return redirect(url_for("listar_sensor"))
    #mensagens de erro e redirecionamento para a tela de listagem de sensores
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_sensor"))
    except Exception as e:
        flash(f"Erro ao excluir o sensor: {e}", "erro")
        return redirect(url_for("listar_sensor"))

#listagem geral de fornecedores
@app.route("/fornecedor/lista")
def listar_fornecedor():
    return render_template("lista_fornecedor.html", fornecedor=Fornecedor.find_all())

#listagem de fornecedores filtrada pelo nome
@app.route("/fornecedor/lista/nome/<string:nome>")
def listar_fornecedor_nome(nome):
    return render_template("lista_fornecedor.html", fornecedor=Fornecedor.find_by_name(nome))

#abre a tela de cadastro de fornecedor para um novo cadastro
@app.route("/fornecedor/novo", methods = ["GET"])
def novo_fornecedor():
    return render_template("for.html", fornecedor=None)

#rota de edição do fornecedor
@app.route("/fornecedor/editar/<int:id>", methods=["GET"])
def editar_fornecedor(id):
    fornecedor = Fornecedor.find_by_id(id)
    if not fornecedor:
        flash("Fornecedor não encontrado.", "erro")
        return redirect(url_for("listar_fornecedor"))
    return render_template("for.html", fornecedor=fornecedor)

#listagem de fornecedores pelo id
@app.route("/fornecedor/listar/id/<int:id>", methods = ["GET"])
def findbyid_fornecedor(id):
    fornecedor = Fornecedor.find_by_id(id)
    if not fornecedor:
        return {"erro": "Fornecedor não encontrado"}, 404
    return render_template("lista_fornecedor.html", fornecedor = Fornecedor.find_by_id(id))
        
@app.route("/fornecedor/salvar", methods=["POST"])
#definição dos campos para o cadastro de fornecedores
def salvar_fornecedor():
    dados = get_fornecedor_form()
    #validação dos dados no campos inseridos
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()
    #mensagem de erro e redirecionamento para o cadastro de fornecedores
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("for.html", fornecedor=dados)
    #inserção dos dados no banco
    try:
        fornecedor.insert()
        #notificação detalhando quem fez o cadastro e qual produto foi cadastrado
        Notificacao.create(
            session["funcionario_id"],
            "Novo fornecedor",
            f"{session['funcionario_nome']} cadastrou o fornecedor {fornecedor.nome}.",
            "fornecedor"
        )
        flash("Fornecedor cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_fornecedor"))
    #mensagem de erro e redirecionamento para a tela de cadastro de fornecedores
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)

@app.route("/fornecedor/buscar", methods=["GET"])
def buscar_fornecedor():
    #captação do nome digitado no campo
    nome = request.args.get("nome", "")
    #caso o campo de busca esteja vazio o usuário é redirecionado a listagem geral de fornecedores
    if nome.strip() == "":
        return redirect(url_for("listar_fornecedor"))
    #listagem de fornecedores com o nome digitado
    fornecedores = Fornecedor.find_by_name(nome)
    #renderização da tela de listagem pós a atuação da função
    return render_template(
        "lista_fornecedor.html",
        fornecedor=fornecedores
    )


@app.route("/fornecedor/atualizar/<int:id>", methods=["POST"])
#definição dos campos a serem atualizados do fornecedor
def atualizar_fornecedor(id):
    dados = get_fornecedor_form()
    dados["id"] = id 
    #validação dos dados dos campos atualizados
    fornecedor = Fornecedor(**dados)
    erros = fornecedor.validate()
    #mensagem de erro e redirecionamento a tela de atualização de fornecedores
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("for.html", fornecedor=dados)
    #o sistema tenta refazer a busca pelo fornecedor para atualizá-lo, caso não dê certo o usuário é redirecionado para a tela de lista geral, se der sucesso a rota ocorre normalmente
    try:
        if not Fornecedor.find_by_id(id):
            flash("Fornecedor não encontrado.", "erro")
            return redirect(url_for("listar_fornecedor"))
        #atualização dos campos do fornecedor
        fornecedor.update(
        dados["nome"], 
        dados["cnpj"], 
        dados["telefone"],id)
        #notificação detalhando quem fez a atualização e com qual fornecedor
        Notificacao.create(
            session["funcionario_id"],
            "Fornecedor editado",
            f"{session['funcionario_nome']} editou o fornecedor {dados['nome']}.",
            "fornecedor"
        )
        flash("Fornecedor atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_fornecedor"))
    #mensagem de erro e redirecionamento para a tela de atualizar fornecedor
    except Exception as e:
        flash(f"Erro ao atualizar fornecedor: {e}", "erro")
        return render_template("for.html", fornecedor=dados)

@app.route("/fornecedor/excluir/<int:id>", methods = ["POST"])
#exclusão do fornecedor
def excluir_fornecedor(id):
    try:
        fornecedor = Fornecedor.find_by_id(id)
        Fornecedor.delete(id)
        #notificação detalhando quem excluiu o fornecedor e qual fornecedor foi excluido
        Notificacao.create(
            session["funcionario_id"],
            "Fornecedor excluído",
            f"{session['funcionario_nome']} excluiu o fornecedor {fornecedor['nome']}.",
            "fornecedor"
        )
        flash("Fornecedor excluído com sucesso.", "sucesso")
        return redirect(url_for("listar_fornecedor"))
    #mensagens de erro e redirecionamento do usuário para a tela de listagem geral de fornecedores
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_fornecedor"))
    except Exception as e:
        if "1451" in str(e):
            flash(
                "Não é possível excluir este fornecedor porque existem produtos vinculados a ele.",
                "erro"
            )
        else:
            flash(f"Erro ao excluir fornecedor: {e}", "erro")
        return redirect(url_for("listar_fornecedor"))

#listagem de funcionarios geral
@app.route("/funcionario/lista")
def listar_funcionario():
    return render_template("lista_funcionario.html", funcionario=Funcionario.find_all())

#listagem de funcionarios filtrado por nome
@app.route("/funcionario/lista/nome/<string:nome>")
def listar_funcionario_nome(nome):
    return render_template("lista_funcionario.html", funcionario=Funcionario.find_by_name(nome))

#renderização da tela de cadastro de novos funcionários
@app.route("/funcionario/novo", methods = ["GET"])
def novo_funcionario():
    return render_template("fun.html", funcionario=None)

#busca de funcionarios pelo nome digitado no campo de busca
@app.route("/funcionario/buscar", methods=["GET"])
def buscar_funcionario():
    #requisitando o nome digitado no campo de busca
    nome = request.args.get("nome", "")
    #se o campo de busca estiver vazio redireciona para a listagem geral de funcionarios
    if nome.strip() == "":
        return redirect(url_for("listar_funcionario"))
    #lista dos funcionarios com o nome digitado no campo de busca
    funcionarios = Funcionario.find_by_name(nome)
    #renderiza a listagem
    return render_template(
        "lista_funcionario.html",
        funcionario=funcionarios
    )

#rota de edição dureta do funcionario
@app.route("/funcionario/editar/<int:id>", methods=["GET"])
def editar_funcionario(id):
    funcionario = Funcionario.find_by_id(id)

    if not funcionario:
        flash("Funcionário não encontrado.", "erro")
        return redirect(url_for("listar_funcionario"))

    return render_template("fun.html", funcionario=funcionario)

#listagem de funcionarios filtrada pelo id digitado
@app.route("/funcionario/lista/id/<int:id>", methods = ["GET"])
def findbyid_funcionario(id):
    funcionario = Funcionario.find_by_id(id)

    if not funcionario:
        return {"erro": "Funcionario não encontrado"}, 404 
    return render_template("lista_funcionario.html", funcionario = Funcionario.find_by_id(id))

@app.route("/funcionario/salvar", methods=["POST"])
#definição dos campos de cadastro
def salvar_funcionario():
    dados = get_funcionario_form()
    #validação dos dados dos campos
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()
    #mensagem de erro e redirecionamento para o cadastro de funcionarios
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("fun.html", funcionario=dados)
    #cadastro do novo funcionario
    try:
        funcionario.insert()
        Notificacao.create(
            session["funcionario_id"],
            "Novo funcionário",
            f"{session['funcionario_nome']} cadastrou o funcionário {funcionario.nome}.",
            "funcionario"
        )
        flash("Funcionario cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_funcionario"))
    #mensagem de erro e redirecionamento para o cadastro de funcionario
    except Exception as e:
        flash(f"Erro ao cadastrar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)

#listagem dos funcionarios filtrado pelo cargo específico
@app.route("/funcionario/lista/cargo/<string:cargo>", methods = ["GET"])
def listar_cargo_funcionario(cargo):
    funcionario = Funcionario.find_by_cargo(cargo)
    if not funcionario:
        flash("Cargo de funcionario não encontrado.", "erro")
        return redirect(url_for("listar_funcionario"))
    return render_template("lista_funcionario.html", funcionario=funcionario)

@app.route("/funcionario/atualizar/<int:id>", methods=["POST"])
#definição dos campos a serem atualizados
def atualizar_funcionario(id):
    dados = get_funcionario_form()
    dados["id"] = id
    #validação dos dados dos campos
    funcionario = Funcionario(**dados)
    erros = funcionario.validate()
    #mensagem de erro e redirecionamento para a tela de atualização
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("fun.html", funcionario=dados)
    #tentativa de encontrar o funcionário para atualizá-lo pelo id, em caso de erro redireciona a lista de funcionarios geral, em caso de sucesso a rota continua normalmente
    try:
        if not Funcionario.find_by_id(id):
            flash("Funcionario não encontrado.", "erro")
            return redirect(url_for("listar_funcionario"))
        #atualização do funcionario
        funcionario.update(
            dados["nome"], 
            dados["cpf"],  
            dados["email"], 
            dados["senha"],
            dados["telefone"],
            dados["cargo"], id)
        #notificação detalhando quem fez a atualização no funcionário e em qual funcionario foi feita a atualização
        Notificacao.create(
            session["funcionario_id"],
            "Funcionário editado",
            f"{session['funcionario_nome']} editou o funcionário {dados['nome']}.",
            "funcionario"
        )
        flash("Funcionario atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_funcionario"))
    #mensagem de erro e redirecionamento para a tela de atualização
    except Exception as e:
        flash(f"Erro ao atualizar funcionario: {e}", "erro")
        return render_template("fun.html", funcionario=dados)
    
@app.route("/funcionario/excluir/<int:id>", methods = ["POST"])
#exclusão do funcionario
def excluir_funcionario(id):
    try:
        funcionario = Funcionario.find_by_id(id)
        Funcionario.delete(id)
        Notificacao.create(
            session["funcionario_id"],
            "Funcionário excluído",
            f"{session['funcionario_nome']} excluiu o funcionário {funcionario['nome']}.",
            "funcionario"
        )
        flash("Funcionario excluído com sucesso.", "sucesso")
        return redirect(url_for("listar_funcionario"))
    #mensagem de erro e redirecionamento para a listagem geral de funcionários
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_funcionario"))
    except Exception as e:
        flash(f"Erro ao excluir funcionario: {e}", "erro")
        return redirect(url_for("listar_funcionario"))

#rota de listagem geral de solicitadores
@app.route("/solicitador/lista")
def listar_solicitador():
    return render_template("lista_solicitador.html", solicitador=Solicitador.find_all())

#rota de listagem de solicitadores filtrada pelo nome
@app.route("/solicitador/lista/nome/<string:nome>")
def listar_solicitador_nome(nome):
    return render_template("lista_solicitador.html", solicitador=Solicitador.find_by_name(nome))

@app.route("/solicitador/buscar", methods=["GET"])
def buscar_solicitador():
    #request do nome dos solicitadores
    nome = request.args.get("nome", "")
    #se nome for == a nada, redireciona para a tela de listagem geral
    if nome.strip() == "":
        return redirect(url_for("listar_solicitador"))
    #faz a busca pelo solicitador usando o valor nome e retorna o solicitador
    solicitadores = Solicitador.find_by_name(nome)
    return render_template("lista_solicitador.html",solicitador=solicitadores)

#rota de redirecionar o usuário para a tela de cadastro de um novo solicitador
@app.route("/solicitador/novo")
def novo_solicitador():
    return render_template("cad_sol.html")

#edição direta do solicitador
@app.route("/solicitador/editar/<int:id>", methods=["GET"])
def editar_solicitador(id):
    solicitador = Solicitador.find_by_id(id)
    if not solicitador:
        flash("Solicitador não encontrado.", "erro")
        return redirect(url_for("listar_solicitador"))
    return render_template("cad_sol.html", solicitador=solicitador)

#listagem de solicitador filtrada pelo id
@app.route("/solicitador/lista/id/<int:id>", methods = ["GET"])
def findbyid_solicitador(id):
    solicitador = Solicitador.find_by_id(id)
    if not solicitador:
        return {"erro": "Solicitador não encontrado"}, 404
    return render_template("lista_solicitador.html",solicitador = Solicitador.find_by_id(id))

@app.route("/solicitador/salvar", methods=["POST"])
def salvar_solicitador():
    #definição dos campos cadastrados
    dados = get_solicitador_form()
    solicitador = Solicitador(**dados)
    #validação dos dados nos campos que serão cadastrados
    erros = solicitador.validate()
    #mensagem de erro e redirecionamento para a tela de cadastro de solicitador (cad_sol.html)
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("cad_sol.html", solicitador=dados)
    #inserção dos dados no banco
    try:
        solicitador.insert()
        #Notificação detalhando quem cadastrou o solicitador e qual é o solicitador cadastrado
        Notificacao.create(
            session["funcionario_id"],
            "Novo solicitador",
            f"{session['funcionario_nome']} cadastrou o solicitador {solicitador.nome}.",
            "solicitador"
        )
        flash("Solicitador cadastrado com sucesso.", "sucesso")
        return redirect(url_for("listar_solicitador"))
    #mensagem de erro e redirecionamento para a tela de cadastro de solicitador (cad_sol.html)
    except Exception as e:
        flash(f"Erro ao cadastrar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)

@app.route("/solicitador/atualizar/<int:id>", methods=["POST"])
#definição dos campos a serem atualizados
def atualizar_solicitador(id):
    dados = get_solicitador_form()
    dados["id"] = id
    #validação dos dados nos campos
    solicitador = Solicitador(**dados)
    erros = solicitador.validate()
    #mensagem de erro e redirecionamento para a tela de atualização de solicitadores
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("cad_sol.html", solicitador=dados)
    #tentativa de encontrar o solicitador para atualizá-lo pelo id, em caso de erro redireciona a lista de solicitadores geral, em caso de sucesso a rota continua normalmente
    try:
        if not Solicitador.find_by_id(id):
            flash("Solicitador não foi encontrado.", "erro")
            return redirect(url_for("listar_solicitador"))
        #atualização dos dados digitados
        solicitador.update(
        dados["nome"], 
        dados["cnpj"], 
        dados["senha"],
        dados["telefone"], id)
        #notificação detalhando quem atualizou qual solicitador e qual solicitador foi atualizado
        Notificacao.create(
            session["funcionario_id"],
            "Solicitador editado",
            f"{session['funcionario_nome']} editou o solicitador {dados['nome']}.",
            "solicitador"
        )
        flash("Solicitador atualizado com sucesso.", "sucesso")
        return redirect(url_for("listar_solicitador"))
    #mensagem de erro e redirecionamento para a tela de atualização de solicitadores
    except Exception as e:
        flash(f"Erro ao atualizar solicitador: {e}", "erro")
        return render_template("cad_sol.html", solicitador=dados)

@app.route("/solicitador/excluir/<int:id>", methods = ["POST"])
#exclusão dos dados de solicitador
def excluir_solicitador(id):
    try:
        solicitador = Solicitador.find_by_id(id)
        Solicitador.delete(id)
        #notificação detalhando quem deletou qual solicitador e o solicitador deletado
        Notificacao.create(
            session["funcionario_id"],
            "Solicitador excluído",
            f"{session['funcionario_nome']} excluiu o solicitador {solicitador['nome']}.",
            "solicitador"
        )
        
        flash("Solicitador excluído com sucesso.", "sucesso")
        return redirect(url_for("listar_solicitador"))
    #mensagens de erro e redirecionamento para a tela de listagem de solicitador
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_solicitador"))
    except Exception as e:
        if "1451" in str(e):
            flash(
                "Não é possível excluir este solicitador porque ele possui solicitações de saída vinculadas.",
                "erro"
            )
        else:
            flash(f"Erro ao excluir solicitador: {e}", "erro")
        return redirect(url_for("listar_solicitador"))

#listagem geral de localização
@app.route("/localizacao/lista")
def listar_localizacao():
    return render_template("lista_localizacao.html", localizacao=Localizacao.find_all())

#listagem de localização filtrado por rua
@app.route("/localizacao/lista/rua/<string:rua>")
def listar_localizacao_rua(rua):
    return render_template("lista_localizacao.html", localizacao=Localizacao.find_by_name(rua))


@app.route("/localizacao/buscar", methods=["GET"])
#dá request no valor rua digitado
def buscar_localizacao():
    rua = request.args.get("rua", "")
    #se o valor de rua for == a nada, a rota redireciona o usuário para a lista de localização geral 
    if rua.strip() == "":
        return redirect(url_for("listar_localizacao"))
    #faz a busca da localização pelo valor rua digitado
    localizacoes = Localizacao.find_by_name(rua)
    #retorna a listagem da localização buscada
    return render_template(
        "lista_localizacao.html",
        localizacao=localizacoes
    )

#redireciona o usuário para a tela inicial de localizações para que o usuário possa cadastrar um novo produto
@app.route("/localizacao/novo")
def nova_localizacao():
    return render_template("localizacao.html")

#edição direta da localização 
@app.route("/localizacao/editar/<int:id>", methods=["GET"])
def editar_localizacao(id):
    localizacao = Localizacao.find_by_id(id)

    if not localizacao:
        flash("Localização não encontrada.", "erro")
        return redirect(url_for("listar_localizacao"))

    return render_template("localizacao.html", localizacao=localizacao)

@app.route("/localizacao/salvar", methods=["POST"])
#Definição dos campos que serão cadastrados
def salvar_localizacao():
    dados = get_localizacao_form()
    #validação dos dados dos campos
    localizacao = Localizacao(**dados)
    erros = localizacao.validate()
    #mensagem de erro e redirecionamento para a tela de cadastro de localização
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("localizacao.html", localizacao=dados)
    #inserção de dados
    try:
        localizacao.insert()
        #notificação detalhando quem inseriu tal localização e qual localização foi inserida
        Notificacao.create(
            session["funcionario_id"],
            "Nova localização",
            f"{session['funcionario_nome']} cadastrou a localização {localizacao.rua}.",
            "localizacao"
        )
        flash("Localização cadastrada com sucesso.", "sucesso")
        return redirect(url_for("listar_localizacao"))
    #mensagem de erro e redirecionamento para a tela de cadastro de localização
    except Exception as e:
        flash(f"Erro ao cadastrar localizacao: {e}", "erro")
        return render_template("localizacao.html", localizacao=dados)

#listagem de localização filtrada pelo id
@app.route("/localizacao/listar/id/<int:id>", methods = ["GET"])
def listar_localizacao_id(id):
    localizacao = Localizacao.find_by_id(id)
    if not localizacao:
        flash("Localização não encontrada.", "erro")
        return redirect(url_for("listar_localizacao"))
    return render_template("lista_localizacao.html", localizacao=localizacao)

@app.route("/localizacao/atualizar/<int:id>", methods=["POST"])
#definição de campos a serem atualizados
def atualizar_localizacao(id):
    dados = get_localizacao_form()
    dados["id"] = id
    #validação dos dados nos campos
    localizacao = Localizacao(**dados)
    erros = localizacao.validate()
    #mensagem de erro e redirecionamento para a tela de atualização da localização
    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("localizacao.html", localizacao=dados)
    #tentativa de encontrar o localização para atualizá-lo pelo id, em caso de erro redireciona a lista de localização geral, em caso de sucesso a rota continua normalmente
    try:
        if not Localizacao.find_by_id(id):
            flash("Localização não encontrada.", "erro")
            return redirect(url_for("listar_localizacao"))
        #atualização dos dados
        localizacao.update(
        dados["rua"], 
        dados["prateleira"], 
        dados["andar"],
        id)
        #notificação detalhando quem atualizou a localização e qual localização foi atualizada
        Notificacao.create(
            session["funcionario_id"],
            "Localização editada",
            f"{session['funcionario_nome']} editou a localização {dados['rua']}.",
            "localizacao"
        )
        flash("Localização atualizada com sucesso.", "sucesso")
        return redirect(url_for("listar_localizacao"))
    #mensagem de erro e redirecionamento para a tela de atualização da localização
    except Exception as e:
        flash(f"Erro ao atualizar localização: {e}", "erro")
        return render_template("localizacao.html", localizacao=dados)

@app.route("/localizacao/excluir/<int:id>", methods = ["POST"])
#exclusão da localização
def excluir_localizacao(id):
    try:
        localizacao = Localizacao.find_by_id(id)
        Localizacao.delete(id)
        #notificação detalhando quem excluiu tal localização e qual localização foi excluída
        Notificacao.create(
            session["funcionario_id"],
            "Localização excluída",
            f"{session['funcionario_nome']} excluiu a localização {localizacao['rua']}.",
            "localizacao"
        )
        flash("Localização excluída com sucesso.", "sucesso")
        return redirect(url_for("listar_localizacao"))
        #mensagens de erro e redirecionamento para a tela de listagem geral de localizações
    except ValueError as e:
        flash(str(e), "erro")
        return redirect(url_for("listar_localizacao"))
    except Exception as e:
        flash(f"Erro ao excluir localização: {e}", "erro")
        return redirect(url_for("listar_localizacao"))

#listagem geral do estoque
@app.route("/estoque", methods = ["GET"])
def listar_estoque():
   return render_template("lista_estoque.html", estoque=Estoque.find_all_stock())

#cadastro do estoque
@app.route("/estoque/salvar", methods=["POST"])
def salvar_estoque():
    dados = get_estoque_form()
    estoque = Estoque(**dados)
    erros = estoque.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("lista_estoque.html", estoque=dados)
    try:
        estoque.insert()
        Notificacao.create(
            session["funcionario_id"],
            "Estoque atualizado",
            f"{session['funcionario_nome']} cadastrou uma quantidade no estoque.",
            "estoque"
        )
        flash("Campos do estoque cadastrados com sucesso.", "sucesso")
        return redirect(url_for("listar_estoque"))
    except Exception as e:
        flash(f"Erro ao cadastrar campos: {e}", "erro")
        return render_template("lista_estoque.html", estoque=dados)

#busca específica pelo id do produto no estoque
@app.route("/estoque/buscar", methods=["GET"])
def buscar_estoque():
    produto_id = request.args.get("produto_id", "")
    if produto_id.strip() == "":
        return redirect(url_for("listar_estoque"))
    try:
        produto_id = int(produto_id)
    except ValueError:
        flash("Digite um ID válido.", "erro")
        return redirect(url_for("listar_estoque"))
    estoque = Estoque.find_product_by_id_stock(produto_id)
    return render_template("lista_estoque.html",estoque=estoque)

#listagem dos produtos no estoque pelo produto_id
@app.route("/estoque/lista/id/<int:produto_id>", methods = ["GET"])
def listar_produto_by_id(produto_id):
   return render_template("lista_estoque.html", estoque=Estoque.find_product_by_id_stock(produto_id))

#listagem geral da solicitação entrada
@app.route("/solicitacao_entrada")
def listar_solicitacao_entrada():
    return render_template("mov_solicitacao_entrada.html", solicitacao_entrada=SolicitacaoEntrada.find_all_with_product())

#redirecionamento do usuário para uma tela de novo cadastro de uma solicitação entrada
@app.route("/solicitacao_entrada/novo", methods = ["GET"])
def novo_solicitacao_entrada():
    return render_template("mov_solicitacao_entrada.html")

#cadastro de uma nova solicitação entrada
@app.route("/solicitacao_entrada/salvar", methods=["POST"])
def salvar_solicitacao_entrada():
    dados = get_solicitacao_entrada_form()

    produto_id = to_int(request.form.get("produto_id", "").strip())
    produto_quantidade = to_int(request.form.get("produto_quantidade", "").strip())

    if not dados.get("data_solicitacao_entrada"):
        dados["data_solicitacao_entrada"] = date.today().strftime('%Y-%m-%d')

    solicitacao_e = SolicitacaoEntrada(**dados)
    erros = solicitacao_e.validate()

    if produto_id <= 0:
        erros.append("Informe um produto válido.")
    if produto_quantidade <= 0:
        erros.append("Informe uma quantidade válida para entrada.")

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("mov_solicitacao_entrada.html", solicitacao_entrada=dados)

    try:
        estoque = Estoque.find_product_by_id_stock(produto_id)

        if not estoque:
            flash("Produto não encontrado no estoque.", "erro")
            return render_template("mov_solicitacao_entrada.html", solicitacao_entrada=dados)

        id_operacao_e = solicitacao_e.insert()

        item_s_entrada = ItemSolicitacaoEntrada(
            id_item_e=0,
            id_operacao_e=id_operacao_e,
            estoque_id=estoque[0]["estoque_id"]
        )
        item_s_entrada.insert()

        sucesso, resultado = Estoque.adicionar_produto(produto_id, produto_quantidade)
        
        if not sucesso:
            flash(resultado, "erro")
            return render_template("mov_solicitacao_entrada.html", solicitacao_entrada=dados)

        flash("Entrada de estoque e solicitação realizadas com sucesso.", "sucesso")
        return redirect(url_for("novo_solicitacao_entrada"))

    except Exception as e:
        flash(f"Erro ao realizar entrada: {e}", "erro")
        return render_template("mov_solicitacao_entrada.html", solicitacao_entrada=dados)

#listagem geral da solicitação de saída
@app.route("/solicitacao_saida")
def listar_solicitacao_saida():
    return render_template("mov_solicitacao_saida.html", solicitacao_saida=SolicitacaoSaida.find_all_with_product())

#redirecionamento do usuário para uma tela de novo cadastro de uma solicitação de saída
@app.route("/solicitacao_saida/novo", methods = ["GET"])
def novo_solicitacao_saida():
    return render_template("mov_solicitacao_saida.html")

#cadastro de uma nova solicitação de saída
@app.route("/solicitacao_saida/salvar", methods=["POST"])
def salvar_solicitacao_saida():
    dados = get_solicitacao_saida_form()

    produto_id = to_int(request.form.get("produto_id", "").strip())
    produto_quantidade = to_int(request.form.get("produto_quantidade", "").strip())

    if not dados.get("data_solicitacao_saida"):
        dados["data_solicitacao_saida"] = date.today().strftime('%Y-%m-%d')

    solicitacao_s = SolicitacaoSaida(**dados)
    erros = solicitacao_s.validate()

    if produto_id <= 0:
        erros.append("Informe um produto válido.")
    if produto_quantidade <= 0:
        erros.append("Informe uma quantidade válida para saída.")

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("mov_solicitacao_saida.html", solicitacao_saida=dados)

    try:
        sucesso, resultado = Estoque.remover_produto(produto_id, produto_quantidade)

        if not sucesso:
            flash(resultado, "erro")
            return render_template("mov_solicitacao_saida.html", solicitacao_saida=dados)

        id_operacao_s = solicitacao_s.insert()

        item_s_saida = ItemSolicitacaoSaida(
            id_item_s=0,
            id_operacao_s=id_operacao_s,
            estoque_id=resultado
        )
        item_s_saida.insert()

        flash("Saída de estoque realizada com sucesso.", "sucesso")
        return redirect(url_for("novo_solicitacao_saida"))

    except Exception as e:
        flash(f"Erro ao solicitar saída: {e}", "erro")
        return render_template("mov_solicitacao_saida.html", solicitacao_saida=dados)

#listagem geral dos itens da solicitação de entrada
@app.route("/item_solicitacao_entrada", methods = ["GET"])
def listar_itens_e():
   return render_template("mov_solicitacao_entrada.html", item_s_e=ItemSolicitacaoEntrada.find_all_with_product())

#insert dos produtos a virarem itens da solicitação de entrada
@app.route("/item_solicitacao_entrada/inserir", methods = ["POST"])
def inserir_itens():
    dados = get_item_solicitacao_entrada_form()
    item_s_entrada = ItemSolicitacaoEntrada(**dados)
    erros = item_s_entrada.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)
    try:
        item_s_entrada.insert()
        flash("Itens cadastrados com sucesso.", "sucesso")
        return redirect(url_for("listar_itens_e"))
    except Exception as e:
        flash(f"Erro ao cadastrar os itens {e}", "erro")
        return render_template("mov_solicitacao_entrada.html", item_solicitacao_entrada=dados)

#listagem geral dos itens da solicitação de saída
@app.route("/item_solicitacao_saida", methods = ["GET"])
def listar_itens_s():
   return render_template("mov_solicitacao_saida.html", item_s_s=ItemSolicitacaoSaida.find_all_with_product())

#insert dos produtos a virarem itens da solicitação de entrada
@app.route("/item_solicitacao_saida/inserir", methods = ["POST"])
def inserir_itens_s():
    dados = get_item_solicitacao_saida_form()
    item_s_saida = ItemSolicitacaoSaida(**dados)
    erros = item_s_saida.validate()

    if erros:
        for erro in erros:
            flash(erro, "erro")
        return render_template("mov_solicitacao_saida.html", item_solicitacao_saida=dados)
    try:
        item_s_saida.insert()
        flash("Itens cadastrados com sucesso.", "sucesso")
        return redirect(url_for("listar_itens_s"))
    except Exception as e:
        flash(f"Erro ao cadastrar os itens {e}", "erro")
        return render_template("mov_solicitacao_saida.html", item_solicitacao_saida=dados)

#finalização do app.py
if __name__ == "__main__":
    app.run(debug=True)
''