// ===============================
// MENU RESPONSIVO
// ===============================

const menuToggle = document.getElementById("menu-toggle");
const menu = document.getElementById("menu");
const menuLinks = document.querySelectorAll(".menu a");

// Abrir/Fechar menu
menuToggle.addEventListener("click", function (event) {
    event.stopPropagation();

    menu.classList.toggle("active");

    if (menu.classList.contains("active")) {
        menuToggle.innerHTML = "✕";
    } else {
        menuToggle.innerHTML = "☰";
    }
});

// Fechar menu ao clicar em um link
menuLinks.forEach(link => {
    link.addEventListener("click", function () {
        menu.classList.remove("active");
        menuToggle.innerHTML = "☰";
    });
});

// Fechar menu ao clicar fora dele
document.addEventListener("click", function (event) {

    const clicouNoMenu = menu.contains(event.target);
    const clicouNoBotao = menuToggle.contains(event.target);

    if (!clicouNoMenu && !clicouNoBotao) {
        menu.classList.remove("active");
        menuToggle.innerHTML = "☰";
    }

});

// Ao voltar para Desktop remove o menu mobile
window.addEventListener("resize", function () {

    if (window.innerWidth > 992) {
        menu.classList.remove("active");
        menuToggle.innerHTML = "☰";
    }

});