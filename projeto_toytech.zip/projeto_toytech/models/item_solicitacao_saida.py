#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa um sensor no sistema
class ItemSolicitacaoSaida(Crud):
    table = "item_solicitacao_saida"
    #lista de campos da tabela
    fields = [
        "id_item_s",
        "id_operacao_s",
        "estoque_id"
    ]

    #criação do objeto da classe
    def __init__(self, id_item_s, id_operacao_s, estoque_id):
        self.id_item_s = id_item_s
        self.id_operacao_s = id_operacao_s
        self.estoque_id = estoque_id

    #Validação dos campos
    def validate(self):
        erros = [
         Validador.required(self.id_operacao_s, "id_operacao_s"),
         Validador.required(self.estoque_id, "estoque_id")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]  

    #listagem de todos os produtos / itens para a solicitação de saída
    @classmethod
    def find_all_with_product(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT solicitacao_saida.id_operacao_s, item_solicitacao_saida.estoque_id FROM solicitacao_saida INNER JOIN item_solicitacao_saida ON solicitacao_saida.id_operacao_s = item_solicitacao_saida.id_operacao_s;"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    #inserção de dados na tabela
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO item_solicitacao_saida
        (id_operacao_s, estoque_id)
        VALUES (%s, %s)
        """
        valores = (
            self.id_operacao_s,
            self.estoque_id
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #método de atualização do item da solicitação de saída
    @classmethod
    def update(cls, produto_quantidade,produto_id, connection=None):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE estoque SET produto_quantidade= %s WHERE produto_id = %s"
            cursor.execute(sql, (produto_quantidade, produto_id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()
