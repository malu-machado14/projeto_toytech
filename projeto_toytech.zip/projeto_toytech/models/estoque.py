from core.conexao import Database
from core.crud import Crud
from core.validar import Validador

#classe que representa um fornecedor no sistema
class Estoque(Crud):

    table = "estoque"
    #lista de campos da tabela
    fields = [
        "estoque_id",
        "produto_id",
        "produto_quantidade"
    ]
    #criação do objeto da classe
    def __init__(self, estoque_id,produto_id=None, produto_quantidade = 0):
        #atribui os valores aos objetos
        self.estoque_id = estoque_id
        self.produto_id = produto_id
        self.produto_quantidade = produto_quantidade

    #função de validação de campos (filtrando os dados que cada um dos campos armazenará ou o quanto de informação será capturada) 
    def validate(self):
        erros = [
             Validador.required(self.produto_id, "produto_id"),
             Validador.required(self.produto_quantidade, "produto_quantidade"),
             Validador.non_negative(self.estoque_id, "estoque_id"),
             Validador.non_negative(self.produto_id, "produto_id"),
             Validador.non_negative(self.produto_quantidade, "produto_quantidade")]
        return [erro for erro in erros if erro]
    
    #função de inserção de dados aos campos da tabela (dados vindos de ambas as movimentações saída e entrada, e do produto)
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        print("RETORNO CADASTRO",self.produto_id)
        sql = """
            INSERT INTO estoque
            (produto_id,produto_quantidade)
            VALUES (%s,%s) 
        """
        valores = (
            self.produto_id,
            self.produto_quantidade
        )

        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()

    #função de atualização do estoque 
    @classmethod
    def update(cls, connection=None):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE estoque SET produto_quantidade = %s  WHERE produto_id = %s"
            cursor.execute(sql, ())
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    #método de listagem total de cada produto existente nesse estoue com sua devida quantidade (sem filtro algum)
    @classmethod
    def find_all_stock(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM estoque"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    #método de listagem do estoque, filtrada para encontrar 1 produto em específico no estoque
    @classmethod
    def find_product_by_id_stock(cls,id):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM estoque WHERE produto_id = %s"
            cursor.execute(sql, (id,))
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    #método de listagem toda do estoque filtrando os produtos por suas quantidades

    @classmethod
    def find_produto_qtd(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT p.nome, e.produto_quantidade as qtd FROM estoque e " \
            "join produto p on e.produto_id = p.id"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    '''função de atualização dos dados no estoque para a entrada de produtos (basicamente a cada nova movimentação de 
    entrada de produtos, essa função ficará responsável de atualizar o estoque, 
    atualizando a quantidade inicial desse campo quantidade que existia no estoque para a quantidade digitada)'''

    @classmethod
    def adicionar_produto(cls, produto_id, quantidade):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        try:
            sql = """
            SELECT *
            FROM estoque
            WHERE produto_id = %s
            """

            cursor.execute(sql, (produto_id,))
            estoque = cursor.fetchone()

            if not estoque:
                return False, "Produto não encontrado no estoque."

            quantidade_atual = estoque["produto_quantidade"]
            nova_quantidade = quantidade_atual + quantidade

            sql_update = """
            UPDATE estoque
            SET produto_quantidade = %s
            WHERE produto_id = %s
            """

            cursor.execute(sql_update, (nova_quantidade, produto_id))
            conexao.commit()

            return True, estoque["estoque_id"]

        except Exception as e:
            conexao.rollback()
            raise e

        finally:
            cursor.close()
            conexao.close()

    '''função de atualização dos dados do estoque para a saída de produtos (fazendo a mesma função que é feita na entrada 
    dos produtos, porém de forma invertida no quesito de ao invés de adicionar, 
    ele diminui a quantia de produtos no estoque atual, atualizando o produto'''
    
    @classmethod
    def remover_produto(cls, produto_id, quantidade):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
    
        try:
            sql = "SELECT * FROM estoque WHERE produto_id = %s"
            cursor.execute(sql, (produto_id,))
            estoque = cursor.fetchone()
    
            if not estoque:
                return False, "Produto não encontrado no estoque."
    
            if estoque["produto_quantidade"] < quantidade:
                return False, f"Estoque insuficiente. Disponível: {estoque['produto_quantidade']}"
    
            nova_quantidade = estoque["produto_quantidade"] - quantidade
    
            sql_update = "UPDATE estoque SET produto_quantidade = %s WHERE produto_id = %s"
            cursor.execute(sql_update, (nova_quantidade, produto_id))
            conexao.commit()
    
            return True, estoque["estoque_id"]
    
        except Exception as e:
            conexao.rollback()
            raise e
        finally:
            cursor.close()
            conexao.close()