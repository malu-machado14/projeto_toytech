from core.conexao import Database


class Notificacao:

    def __init__(
        self,
        id=None,
        funcionario_id=None,
        titulo=None,
        mensagem=None,
        tipo=None,
        lida=False,
        data_hora=None
    ):
        self.id = id
        self.funcionario_id = funcionario_id
        self.titulo = titulo
        self.mensagem = mensagem
        self.tipo = tipo
        self.lida = lida
        self.data_hora = data_hora

    @staticmethod
    def create(funcionario_id, titulo, mensagem, tipo):
        conexao = None
        cursor = None

        try:
            conexao = Database.connect()
            cursor = conexao.cursor()

            # Verifica se o funcionário existe
            cursor.execute(
                """
                SELECT id
                FROM funcionario
                WHERE id = %s
                """,
                (funcionario_id,)
            )

            funcionario = cursor.fetchone()

            if not funcionario:
                print(
                    f"AVISO: notificação não criada. "
                    f"O funcionário {funcionario_id} não existe."
                )
                return False

            # Cria a notificação
            cursor.execute(
                """
                INSERT INTO notificacao
                (funcionario_id, titulo, mensagem, tipo)
                VALUES (%s, %s, %s, %s)
                """,
                (
                    funcionario_id,
                    titulo,
                    mensagem,
                    tipo
                )
            )

            conexao.commit()
            return True

        except Exception as e:
            if conexao:
                conexao.rollback()

            print(f"ERRO AO CRIAR NOTIFICAÇÃO: {e}")
            return False

        finally:
            if cursor:
                cursor.close()

            if conexao:
                conexao.close()

'''
#import
from core.conexao import Database

#classe Notificação
class Notificacao:
    #criação do objeto da classe
    def __init__(
        self,
        id=None,
        funcionario_id=None,
        titulo=None,
        mensagem=None,
        tipo=None,
        lida=False,
        data_hora=None
    ):
        self.id = id
        self.funcionario_id = funcionario_id
        self.titulo = titulo
        self.mensagem = mensagem
        self.tipo = tipo
        self.lida = lida
        self.data_hora = data_hora


    # CADASTRAR
    @staticmethod
    def create(funcionario_id, titulo, mensagem, tipo):
        conexao = Database.connect()
        cursor = conexao.cursor()
        sql = """
            INSERT INTO notificacao
            (funcionario_id, titulo, mensagem, tipo)
            VALUES (%s, %s, %s, %s)
        """
        valores = (
            funcionario_id,
            titulo,
            mensagem,
            tipo
        )
        cursor.execute(sql, valores)
        conexao.commit()
        cursor.close()
        conexao.close()
'''