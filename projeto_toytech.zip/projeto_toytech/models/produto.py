# imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador
import base64


# classe que representa o produto
class Produto(Crud):

    table = "produto"

    # lista de campos da tabela
    fields = [
        "id",
        "nome",
        "descricao",
        "fornecedor_id",
        "localizacao_produto",
        "imagem_nome",
        "imagem_tipo",
        "imagem_blob",
        "preco"
    ]

    # inicializa o objeto
    def __init__(
        self,
        nome,
        descricao,
        localizacao_produto,
        preco,
        fornecedor_id,
        imagem_nome,
        imagem_tipo,
        imagem_blob=None,
        id=None
    ):
        self.id = id
        self.nome = nome
        self.descricao = descricao
        self.fornecedor_id = fornecedor_id
        self.localizacao_produto = localizacao_produto
        self.imagem_nome = imagem_nome
        self.imagem_tipo = imagem_tipo
        self.imagem_blob = imagem_blob
        self.preco = preco

    # VALIDAÇÃO DOS CAMPOS

    def validate(self):

        erros = [
            Validador.required(self.nome, "nome"),
            Validador.required(self.descricao, "descricao"),
            Validador.required(self.fornecedor_id, "fornecedor_id"),
            Validador.required(
                self.localizacao_produto,
                "localizacao_produto"
            ),
            Validador.required(self.preco, "preco"),
            Validador.required(self.imagem_blob, "imagem_blob"),
            Validador.required(self.imagem_nome, "imagem_nome"),
            Validador.required(self.imagem_tipo, "imagem_tipo"),
            Validador.not_have_number(
                self.nome,
                "nome"
            ),

            Validador.have_number(
                self.fornecedor_id,
                "fornecedor_id"
            ),

            Validador.have_number(
                self.localizacao_produto,
                "localizacao_produto"
            ),

            Validador.price(
                self.preco,
                "preco"
            )
        ]

        return [erro for erro in erros if erro]

    # INSERIR OS DADOS NO PRODUTO

    def insert(self):

        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
            INSERT INTO produto
            (
                nome,
                descricao,
                imagem_nome,
                imagem_tipo,
                imagem_blob,
                preco,
                fornecedor_id,
                localizacao_produto
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        valores = (
            self.nome,
            self.descricao,
            self.imagem_nome,
            self.imagem_tipo,
            self.imagem_blob,
            self.preco,
            self.fornecedor_id,
            self.localizacao_produto
        )

        try:

            cursor.execute(sql, valores)
            produto_id = cursor.lastrowid
            conexao.commit()

        except Exception:
            conexao.rollback()
            raise

        finally:

            cursor.close()
            conexao.close()
        return produto_id

    # BUSCAR TODOS OS PRODUTOS

    @classmethod
    def find_all(cls):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        try:

            sql = "SELECT * FROM produto"

            cursor.execute(sql)

            resultados = cursor.fetchall()

        finally:

            cursor.close()
            conexao.close()

        produtos = []

        for dados in resultados:

            imagem_base64 = None

            if dados["imagem_blob"]:
                imagem_base64 = base64.b64encode(dados["imagem_blob"]).decode("utf-8")

            produto = cls(
                id=dados["id"],
                nome=dados["nome"],
                descricao=dados["descricao"],
                fornecedor_id=dados["fornecedor_id"],
                localizacao_produto=dados["localizacao_produto"],
                imagem_nome=dados["imagem_nome"],
                imagem_tipo=dados["imagem_tipo"],
                imagem_blob=imagem_base64,
                preco=dados["preco"]
            )

            produtos.append(produto)

        return produtos

    # BUSCAR OS PRODUTOS POR NOME

    @classmethod
    def find_by_name(cls, nome):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        try:

            sql = """
                SELECT *
                FROM produto
                WHERE nome LIKE %s
                ORDER BY nome
            """

            cursor.execute(sql, (f"%{nome}%",))

            resultados = cursor.fetchall()

        finally:

            cursor.close()
            conexao.close()

        produtos = []

        for dados in resultados:

            imagem_base64 = None

            if dados["imagem_blob"]:

                imagem_base64 = base64.b64encode(
                    dados["imagem_blob"]
                ).decode("utf-8")

            produto = cls(
                id=dados["id"],
                nome=dados["nome"],
                descricao=dados["descricao"],
                fornecedor_id=dados["fornecedor_id"],
                localizacao_produto=dados["localizacao_produto"],
                imagem_nome=dados["imagem_nome"],
                imagem_tipo=dados["imagem_tipo"],
                imagem_blob=imagem_base64,
                preco=dados["preco"]
            )

            produtos.append(produto)

        return produtos

    # BUSCAR OS PRODUTOS POR PREÇO

    @classmethod
    def find_by_price(cls, preco):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        try:

            sql = """
                SELECT *
                FROM produto
                WHERE preco = %s
                ORDER BY preco
            """

            cursor.execute(sql, (preco,))

            resultados = cursor.fetchall()

        finally:

            cursor.close()
            conexao.close()

        produtos = []

        for dados in resultados:

            imagem_base64 = None

            if dados["imagem_blob"]:

                imagem_base64 = base64.b64encode(
                    dados["imagem_blob"]
                ).decode("utf-8")

            produto = cls(
                id=dados["id"],
                nome=dados["nome"],
                descricao=dados["descricao"],
                fornecedor_id=dados["fornecedor_id"],
                localizacao_produto=dados["localizacao_produto"],
                imagem_nome=dados["imagem_nome"],
                imagem_tipo=dados["imagem_tipo"],
                imagem_blob=imagem_base64,
                preco=dados["preco"]
            )

            produtos.append(produto)

        return produtos

    # BUSCAR PRODUTOS POR ID

    @classmethod
    def find_by_id(cls, id):

        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)

        try:

            sql = """
                SELECT *
                FROM produto
                WHERE id = %s
            """

            cursor.execute(sql, (id,))

            dados = cursor.fetchone()

        finally:

            cursor.close()
            conexao.close()

        if not dados:
            return None

        imagem_base64 = None

        if dados["imagem_blob"]:

            imagem_base64 = base64.b64encode(
                dados["imagem_blob"]
            ).decode("utf-8")

        produto = cls(
            id=dados["id"],
            nome=dados["nome"],
            descricao=dados["descricao"],
            fornecedor_id=dados["fornecedor_id"],
            localizacao_produto=dados["localizacao_produto"],
            imagem_nome=dados["imagem_nome"],
            imagem_tipo=dados["imagem_tipo"],
            imagem_blob=imagem_base64,
            preco=dados["preco"]
        )

        return produto

    # ATUALIZAR OS DADOS DO PRODUTO

    @classmethod
    def update(
        cls,
        nome,
        descricao,
        preco,
        id,
        imagem_nome=None,
        imagem_tipo=None,
        imagem_blob=None,
        connection=None
    ):
        conexao_propria = connection is None

        if conexao_propria:
            conexao = Database.connect()
        else:
            conexao = connection

        cursor = conexao.cursor()

        try:
            if imagem_blob:
                sql = """
                    UPDATE produto
                    SET
                        nome = %s,
                        descricao = %s,
                        imagem_nome = %s,
                        imagem_tipo = %s,
                        imagem_blob = %s,
                        preco = %s
                    WHERE id = %s
                """

                valores = (
                    nome,
                    descricao,
                    imagem_nome,
                    imagem_tipo,
                    imagem_blob,
                    preco,
                    id
                )

            else:
                sql = """
                    UPDATE produto
                    SET
                        nome = %s,
                        descricao = %s,
                        preco = %s
                    WHERE id = %s
                """

                valores = (
                    nome,
                    descricao,
                    preco,
                    id
                )

            cursor.execute(sql, valores)

            if conexao_propria:
                conexao.commit()

            return cursor.rowcount

        except Exception:
            if conexao_propria:
                conexao.rollback()
            raise

        finally:
            cursor.close()

            if conexao_propria:
                conexao.close()

    # DELETAR O PRODUTO

    @classmethod
    def delete(cls, id):

        conexao = Database.connect()
        cursor = conexao.cursor()
        try:

            # Exclui primeiro os registros do estoque
            sql_estoque = """
                DELETE FROM estoque
                WHERE produto_id = %s
            """

            cursor.execute(sql_estoque, (id,))

            # Depois exclui o produto
            sql_produto = """
                DELETE FROM produto
                WHERE id = %s
            """

            cursor.execute(sql_produto, (id,))

            conexao.commit()
            linhas = cursor.rowcount
            return linhas

        except Exception:

            conexao.rollback()
            raise

        finally:

            cursor.close()
            conexao.close()