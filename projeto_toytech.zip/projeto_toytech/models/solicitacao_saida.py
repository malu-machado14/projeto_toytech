#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa um sensor no sistema
class SolicitacaoSaida(Crud):
    table = "solicitacao_saida"
    #lista de campos da tabela
    fields = [
        "id_operacao_s",
        "data_solicitacao_saida",
        "observacao",
        "funcionario_id",
        "solicitador_id",
    ]

    #criação do objeto da classe
    def __init__(self, id_operacao_s, data_solicitacao_saida, observacao,funcionario_id,solicitador_id):
        self.id_operacao_s = id_operacao_s
        self.data_solicitacao_saida = data_solicitacao_saida
        self.observacao = observacao
        self.funcionario_id = funcionario_id
        self.solicitador_id = solicitador_id
    
    #validação dos campos
    def validate(self):
        erros = [
         Validador.required(self.id_operacao_s, "id_operacao_s"),
         Validador.required(self.data_solicitacao_saida, "data_solicitacao_saida"),
         Validador.required(self.observacao, "observacao"),
         Validador.required(self.funcionario_id, "funcionario_id"),
         Validador.required(self.solicitador_id, "solicitador_id")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #inserção dos dados nos campos
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO solicitacao_saida
        (funcionario_id,observacao,solicitador_id,data_solicitacao_saida)
        VALUES (%s,%s,%s,%s)
        """
        valores = (
            self.funcionario_id,
            self.observacao,
            self.solicitador_id,
            self.data_solicitacao_saida,
        )

        cursor.execute(sql, valores)
        id_operacao_s = cursor.lastrowid
        conexao.commit()
        cursor.close()
        conexao.close()
        return id_operacao_s

    #listagem geral de todas as solicitações de saída
    @classmethod
    def find_all_with_product(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT 
                    s.id_operacao_s, 
                    s.data_solicitacao_saida, 
                    s.funcionario_id, 
                    s.solicitador_id, 
                    s.observacao,
                    p.id AS produto_id,
                    p.nome AS nome_produto,
                    p.preco AS preco_produto,
                    e.produto_quantidade,
                    (p.preco * e.produto_quantidade) AS preco_total
                FROM solicitacao_saida s
                JOIN item_solicitacao_saida i ON s.id_operacao_s = i.id_operacao_s
                JOIN estoque e ON i.estoque_id = e.estoque_id
                JOIN produto p ON e.produto_id = p.id
                ORDER BY s.id_operacao_s DESC
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()