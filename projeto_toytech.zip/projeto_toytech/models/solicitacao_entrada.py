#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador
#classe que representa um sensor no sistema
class SolicitacaoEntrada(Crud):
    table = "solicitacao_entrada"
    #lista de campos da tabela
    fields = [
        "id_operacao_e",
        "data_solicitacao_entrada",
        "funcionario_id",
        "fornecedor_id",
        "observacao",
    ]

    #criação do objeto da classe
    def __init__(self, id_operacao_e, data_solicitacao_entrada, funcionario_id, fornecedor_id, observacao=None):
        self.id_operacao_e = id_operacao_e
        self.data_solicitacao_entrada = data_solicitacao_entrada
        self.funcionario_id = funcionario_id
        self.fornecedor_id = fornecedor_id
        self.observacao = observacao

    #validação dos campos
    def validate(self):
        erros = [
         Validador.required(self.id_operacao_e, "id_operacao_e"),
         Validador.required(self.data_solicitacao_entrada, "data_solicitacao_entrada"),
         Validador.required(self.observacao, "observacao"),
         Validador.required(self.funcionario_id, "funcionario_id"),
         Validador.required(self.fornecedor_id, "fornecedor_id")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]  

    #inserção dos dados nos campos
    def insert(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO solicitacao_entrada
        (funcionario_id, fornecedor_id, observacao, data_solicitacao_entrada)
        VALUES (%s, %s, %s, %s)
        """
        valores = (
            self.funcionario_id,
            self.fornecedor_id,
            self.observacao,
            self.data_solicitacao_entrada
        )

        try:
            cursor.execute(sql, valores)
            id_operacao_e = cursor.lastrowid  # <--- Captura o ID gerado pelo MySQL
            conexao.commit()
            return id_operacao_e  # <--- Retorna o ID para usar no app.py
        except Exception:
            conexao.rollback()
            raise
        finally:
            cursor.close()
            conexao.close()

    #listagem geral de todas as solicitações de entrada
    @classmethod
    def find_all_with_product(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT * from solicitacao_entrada
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()