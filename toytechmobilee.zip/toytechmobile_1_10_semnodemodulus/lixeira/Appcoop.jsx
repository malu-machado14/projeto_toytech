import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Login from '../screens/login';
import Dashboard from '../screens/dashboard';
import ListagemProd from '../screens/listagemprod';
import SoliEntrada from '../screens/solientrada';
import SoliSaida from '../screens/solisaida';



const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          name="Login"
          component={Login}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Dashboard"
          component={Dashboard}
          
        />
        <Stack.Screen
          name="Produtos"
          component={ListagemProd}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Entrada"
          component={SoliEntrada}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Saida"
          component={SoliSaida}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}