import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, ImageBackground, Alert, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import api from '../../src/services/api';

export default function login({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [sucesso, setSucesso] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !senha) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    setLoading(true);
    setMensagem('');

    try {
      // Aponta para a rota correta do backend
      const response = await api.post('/api/login', { email, senha });

      if (response.data.success) {
        setSucesso(true);
        setMensagem('Login realizado com sucesso!');

        // Captura o objeto "user" retornado (contendo id, nome, cpf, email, telefone, cargo)
        const usuarioLogado = response.data.user;

        // Navega para a tela principal repassando os dados do funcionário
        navigation.navigate('App', { user: usuarioLogado });
      } else {
        setSucesso(false);
        setMensagem(response.data.message || 'Email ou senha incorretos.');
      }

    } catch (error) {
      setSucesso(false);
      
      const mensagemErro = error.response?.data?.message || 'Falha ao conectar ao servidor.';
      setMensagem(mensagemErro);
      
      Alert.alert('Erro', mensagemErro);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>

        <View style={styles.card}>

          <Image
            source={require('../assets/imgs/logo.png')}
            style={styles.logo}
          />

          <Text style={styles.titulo}>
            Sistema de estoque
          </Text>

          <Text style={styles.subtitulo}>
            Faça seu login abaixo:
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#ffffff"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <TextInput
            style={styles.input}
            placeholder="Senha"
            placeholderTextColor="#ffffff"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry={true}
          />

          <TouchableOpacity
            style={styles.botao}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.textoBotao}>
                Entrar
              </Text>
            )}
          </TouchableOpacity>

          {mensagem !== '' && (
            <Text
              style={[
                styles.mensagem,
                {
                  color: sucesso
                    ? '#7CFF92'
                    : '#FF6B6B'
                }
              ]}
            >
              {mensagem}
            </Text>
          )}

        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    justify: 'center',
    padding: 20,
    backgroundColor: 'rgba(0,0,0,0.35)'
  },
  card: {
    backgroundColor: 'rgba(32, 58, 130, 0.55)',
    borderRadius: 30,
    padding: 25,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    elevation: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8
    },
    shadowOpacity: 0.4,
    shadowRadius: 15
  },
  logo: {
    width: 180,
    height: 100,
    marginBottom: 10,
    resizeMode: 'contain',
    alignSelf: 'center'
  },
  titulo: {
    textAlign: 'center',
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8
  },
  subtitulo: {
    textAlign: 'center',
    fontSize: 16,
    color: '#dfe9ff',
    marginBottom: 25,
    fontWeight: '600'
  },
  input: {
    backgroundColor: 'rgba(125, 118, 192, 0.62)',
    borderRadius: 16,
    padding: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.4)',
    fontSize: 15,
    color: '#ffffff'
  },
  botao: {
    backgroundColor: '#2376c9',
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 5
  },
  textoBotao: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
  mensagem: {
    marginTop: 20,
    textAlign: 'center',
    fontSize: 15,
    fontWeight: 'bold'
  }
});