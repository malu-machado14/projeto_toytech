import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import api from '../../src/services/api';
import {
  estoque,
  totalEntradas,
  totalSaidas
} from '../estoque';

export default function Dashboard({ navigation }) {

  const [dashboardData, setDashboardData] = useState({
    totalProducts: 0,
    lowStockCount: 0,
    recentActivities: [],
  });

  const loadDashboard = async () => {
    try {
      const response = await api.get('/dashboard');
      setDashboardData(response.data);
    } catch (error) {
      console.log('Erro ao carregar Dashboard:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadDashboard();
    }, [])
  );
  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.welcome}>
              Bem-vindo a ToyTech!
            </Text>

            <Text style={styles.userName}>
              Sistema de Estoque
            </Text>
          </View>

          <TouchableOpacity style={styles.notification}>
            <Ionicons
              name="notifications-outline"
              size={24}
              color="#fff"
            />
          </TouchableOpacity>
        </View>

        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>
            Produtos em Estoque
          </Text>

          <Text style={styles.balanceValue}>
            {estoque}
          </Text>

          <View style={styles.balanceFooter}>
            <Ionicons
              name="trending-up"
              size={18}
              color="#22C55E"
            />

            <Text style={styles.balanceGrowth}>

            </Text>
          </View>
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statsCardGreen}>
            <Ionicons
              name="arrow-down-circle"
              size={24}
              color="#22C55E"
            />

            <Text style={styles.statsNumber}>
              {totalEntradas}
            </Text>

            <Text style={styles.statsLabel}>
              Entradas
            </Text>
          </View>

          <View style={styles.statsCardRed}>
            <Ionicons
              name="arrow-up-circle"
              size={24}
              color="#EF4444"
            />

            <Text style={styles.statsNumber}>
              {totalSaidas}
            </Text>

            <Text style={styles.statsLabel}>
              Saídas
            </Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>
          Operações
        </Text>

        <TouchableOpacity
          style={styles.actionButtonBlue}
          onPress={() => navigation.navigate('Produtos')}
        >
          <View style={styles.buttonContent}>
            <Ionicons
              name="cube-outline"
              size={26}
              color="#fff"
            />

            <View>
              <Text style={styles.buttonTitle}>
                Produtos
              </Text>

              <Text style={styles.buttonSubtitle}>
                Visualizar estoque completo
              </Text>
            </View>
          </View>

          <Ionicons
            name="chevron-forward"
            size={22}
            color="#fff"
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButtonGreen}
          onPress={() => navigation.navigate('Entrada')}
        >
          <View style={styles.buttonContent}>
            <Ionicons
              name="arrow-down-circle-outline"
              size={26}
              color="#fff"
            />

            <View>
              <Text style={styles.buttonTitle}>
                Entrada de Estoque
              </Text>

              <Text style={styles.buttonSubtitle}>
                Registrar novos produtos
              </Text>
            </View>
          </View>

          <Ionicons
            name="chevron-forward"
            size={22}
            color="#fff"
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButtonRed}
          onPress={() => navigation.navigate('Saida')}
        >
          <View style={styles.buttonContent}>
            <Ionicons
              name="arrow-up-circle-outline"
              size={26}
              color="#fff"
            />

            <View>
              <Text style={styles.buttonTitle}>
                Saída de Estoque
              </Text>

              <Text style={styles.buttonSubtitle}>
                Registrar retirada
              </Text>
            </View>
          </View>

          <Ionicons
            name="chevron-forward"
            size={22}
            color="#fff"
          />
        </TouchableOpacity>

      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },

  container: {
    flex: 1,
    backgroundColor: 'transparent',
    paddingHorizontal: 20,
  },

  header: {
    marginTop: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  welcome: {
    color: '#ffffff',
    fontSize: 15,
  },

  userName: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 3,
  },

  notification: {
    width: 50,
    height: 50,
    backgroundColor: '#1E293B',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  balanceCard: {
    backgroundColor: '#09276881',
    borderRadius: 30,
    padding: 25,
    marginTop: 30,
  },

  balanceLabel: {
    color: '#DBEAFE',
    fontSize: 16,
  },

  balanceValue: {
    color: '#fff',
    fontSize: 42,
    fontWeight: 'bold',
    marginTop: 10,
  },

  balanceFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },

  balanceGrowth: {
    color: '#DCFCE7',
    marginLeft: 6,
    fontWeight: '600',
  },

  sectionTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 18,
  },

  actionButtonBlue: {
    backgroundColor: '#09276881',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonGreen: {
    backgroundColor: '#16a34ab7',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonRed: {
    backgroundColor: '#dc26268d',
    borderRadius: 24,
    padding: 20,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },

  buttonTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },

  buttonSubtitle: {
    color: '#E2E8F0',
    marginTop: 3,
    fontSize: 13,
  },

  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 25,
    marginTop: 15,
  },

  statsCardGreen: {
    width: '48%',
    backgroundColor: '#052E16',
    borderRadius: 24,
    padding: 20,
  },

  statsCardRed: {
    width: '48%',
    backgroundColor: '#450A0A',
    borderRadius: 24,
    padding: 20,
  },

  statsNumber: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 12,
  },

  statsLabel: {
    color: '#CBD5E1',
    marginTop: 6,
  },
});