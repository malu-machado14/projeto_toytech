import React, { useState, useEffect } from 'react';

import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    ImageBackground,
    Alert
} from 'react-native';

import QRCodeScannerModal from '../QRCodeScannerModal';
import { Ionicons } from '@expo/vector-icons';
import api from '../../src/services/api';
import {
    estoque,
    adicionarEstoque,
} from '../estoque';



export default function SoliEntrada({ navigation, route }) {

    const [product, setProduct] = useState(null);
    const [code, setCode] = useState('');
    const [quantity, setQuantity] = useState('');
    const [isScannerOpen, setIsScannerOpen] = useState(false);

    useEffect(() => {
        if (route?.params?.produto) {
            setProduct(route.params.produto);
            setCode(
                String(
                    route.params.produto.code ||
                    route.params.produto.id
                )
            );
        }
    }, [route?.params?.produto]);

    const handleReadQRCode = (data) => {

        setIsScannerOpen(false);

        Alert.alert(
            'QR Code lido',
            `Código encontrado: ${data}`
        );

        setCode(data);
    };

    function confirmarEntrada() {

        const qtd = Number(quantity);

        if (!quantity || qtd <= 0) {
            Alert.alert(
                'Atenção',
                'Digite uma quantidade válida.'
            );
            return;
        }

        const novoEstoque = adicionarEstoque(qtd);

        Alert.alert(
            'Sucesso',
            `Entrada registrada!\n\nQuantidade: ${qtd}\nNovo estoque: ${novoEstoque}`
        );

        setQuantity('');
    }

    return (
        <ImageBackground
            source={require('../assets/imgs/fundo.png')}
            style={styles.background}
            resizeMode="cover"
        >

            <ScrollView
                style={styles.container}
                showsVerticalScrollIndicator={false}
            >

                {/* BOTÃO VOLTAR */}

                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    style={styles.backButton}
                >
                    <Ionicons
                        name="arrow-back"
                        size={30}
                        color="#fff"
                    />
                </TouchableOpacity>

                {/* HEADER */}

                <View style={styles.header}>
                    <Text style={styles.title}>
                        Entrada de Estoque
                    </Text>

                    <Text style={styles.subtitle}>
                        Registre produtos rapidamente
                    </Text>
                </View>

                {/* QR CODE */}

                <TouchableOpacity
                    style={styles.qrButton}
                    onPress={() => setIsScannerOpen(true)}
                >
                    <View style={styles.qrContent}>
                        <Ionicons
                            name="qr-code-outline"
                            size={32}
                            color="#fff"
                        />

                        <View>
                            <Text style={styles.qrTitle}>
                                Ler QR Code
                            </Text>

                            <Text style={styles.qrSubtitle}>
                                Escanear produto
                            </Text>
                        </View>
                    </View>

                    <Ionicons
                        name="chevron-forward"
                        size={22}
                        color="#fff"
                    />
                </TouchableOpacity>

                <QRCodeScannerModal
                    visible={isScannerOpen}
                    onClose={() => setIsScannerOpen(false)}
                    onReadCode={handleReadQRCode}
                />

                {/* PRODUTO */}

                <Text style={styles.sectionTitle}>
                    Produto Encontrado
                </Text>

                <View style={styles.productCard}>
                    <View style={styles.productIcon}>
                        <Ionicons
                            name="cube"
                            size={28}
                            color="#3B82F6"
                        />
                    </View>

                    <View style={{ flex: 1 }}>
                        <Text style={styles.productName}>
                            {product ? product.name : 'Nenhum produto selecionado'}
                        </Text>

                        <Text style={styles.productCode}>
                            Código: {code}
                        </Text>

                        <Text style={styles.productStock}>
                            Estoque Atual: {product ? product.stock : estoque}
                        </Text>
                    </View>
                </View>

                {/* QUANTIDADE */}

                <Text style={styles.sectionTitle}>
                    Quantidade
                </Text>

                <TextInput
                    style={styles.input}
                    placeholder="Digite a quantidade"
                    placeholderTextColor="#94A3B8"
                    keyboardType="numeric"
                    value={quantity}
                    onChangeText={setQuantity}
                />

                {/* RESUMO */}

                <View style={styles.summaryCard}>
                    <Text style={styles.summaryTitle}>
                        Resumo da Entrada
                    </Text>

                    <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>
                            Produto
                        </Text>

                        <Text style={styles.summaryValue}>
                            {product ? product.name : "Nenhum produto selecionado"}
                        </Text>
                    </View>

                    <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>
                            Quantidade
                        </Text>

                        <Text style={styles.summaryValue}>
                            {quantity || 0}
                        </Text>
                    </View>

                    <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>
                            Estoque Final
                        </Text>

                        <Text style={styles.summaryValueGreen}>
                            {estoque + Number(quantity || 0)}
                        </Text>
                    </View>
                </View>

                {/* BOTÃO CONFIRMAR */}

                <TouchableOpacity
                    style={styles.confirmButton}
                    onPress={confirmarEntrada}
                >
                    <Ionicons
                        name="checkmark-circle"
                        size={24}
                        color="#fff"
                    />

                    <Text style={styles.confirmText}>
                        Confirmar Entrada
                    </Text>
                </TouchableOpacity>

                <View style={{ height: 40 }} />
            </ScrollView>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({

    background: {
        flex: 1,
    },

    container: {
        flex: 1,
        backgroundColor: 'transparent',
        paddingHorizontal: 20,
    },

    backButton: {
        marginTop: 20,
        alignSelf: 'flex-start',
    },

    header: {
        marginTop: 20,
    },

    title: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },

    subtitle: {
        color: '#ffffff',
        marginTop: 5,
        fontSize: 15,
    },

    qrButton: {
        backgroundColor: '#3c5fbc',
        borderRadius: 25,
        padding: 22,
        marginTop: 30,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },

    qrContent: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 15,
    },

    qrTitle: {
        color: '#ffffff',
        fontSize: 18,
        fontWeight: 'bold',
    },

    qrSubtitle: {
        color: '#ffffff',
        marginTop: 3,
    },

    sectionTitle: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 35,
        marginBottom: 15,
    },

    productCard: {
        backgroundColor: '#1E293B',
        borderRadius: 22,
        padding: 20,
        flexDirection: 'row',
        alignItems: 'center',
    },

    productIcon: {
        width: 65,
        height: 65,
        backgroundColor: '#172554',
        borderRadius: 18,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },

    productName: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },

    productCode: {
        color: '#ffffff',
        marginTop: 5,
    },

    productStock: {
        color: '#22C55E',
        marginTop: 8,
        fontWeight: 'bold',
    },

    input: {
        backgroundColor: '#1E293B',
        height: 65,
        borderRadius: 18,
        paddingHorizontal: 20,
        color: '#ffffff',
        fontSize: 18,
    },

    summaryCard: {
        backgroundColor: '#1E293B',
        borderRadius: 22,
        padding: 22,
        marginTop: 35,
    },

    summaryTitle: {
        color: '#ffffff',
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 20,
    },

    summaryRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 15,
    },

    summaryLabel: {
        color: '#ffffff',
        fontSize: 15,
    },

    summaryValue: {
        color: '#ffffff',
        fontWeight: 'bold',
    },

    summaryValueGreen: {
        color: '#22C55E',
        fontWeight: 'bold',
    },

    confirmButton: {
        backgroundColor: '#16A34A',
        height: 65,
        borderRadius: 22,
        marginTop: 35,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
    },

    confirmText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});















