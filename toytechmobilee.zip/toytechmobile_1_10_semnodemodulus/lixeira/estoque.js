/*export let estoque = 25;

export let totalEntradas = 0;
export let totalSaidas = 0;

export function adicionarEstoque(qtd) {
    estoque += qtd;
    totalEntradas += qtd;

    return estoque;
}

export function removerEstoque(qtd) {
    estoque -= qtd;
    totalSaidas += qtd;

    return estoque;
}
    */



export let estoque = 43;

export let totalEntradas = 0;

export let totalSaidas = 0;


// PRODUTOS
export let produtos = [
    {
        id: 1,
        nome: 'Baby Alive',
        codigo: 'PRD-10245',
        estoque: 10
    },
    {
        id: 2,
        nome: 'Hot Wheels',
        codigo: 'PRD-94821',
        estoque: 25
    },
    {
        id: 3,
        nome: 'Cubo Mágico',
        codigo: 'PRD-56321',
        estoque: 15
    },
    {
        id: 4,
        nome: 'Buzz Lightyear',
        codigo: 'PRD-93749',
        estoque: 20
    },
    {
        id: 5,
        nome: 'BayBlade',
        codigo: 'PRD-39740',
        estoque: 30,
    }
];


// BUSCAR PRODUTO PELO QR CODE
export function buscarProduto(codigo) {

    return produtos.find(
        produto => produto.codigo === String(codigo)
    );
}


// ENTRADA
export function adicionarEstoque(qtd) {

    estoque += qtd;

    totalEntradas += qtd;

    return estoque;
}


// SAÍDA
export function removerEstoque(qtd) {

    estoque -= qtd;

    totalSaidas += qtd;

    return estoque;
}