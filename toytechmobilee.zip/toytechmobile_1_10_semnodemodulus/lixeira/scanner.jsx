import React, { useState } from 'react';

import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';

import {
    CameraView,
    useCameraPermissions,
} from 'expo-camera';

export default function ScannerScreen({ navigation, route }) {

    const [permission, requestPermission] =
        useCameraPermissions();

    const [scaneado, setScaneado] = useState(false);


    // =====================================================
    // CARREGANDO PERMISSÃO
    // =====================================================

    if (!permission) {

        return (
            <View style={styles.center}>

                <Text style={styles.texto}>
                    Carregando câmera...
                </Text>

            </View>
        );
    }


    // =====================================================
    // PEDIR PERMISSÃO
    // =====================================================

    if (!permission.granted) {

        return (
            <View style={styles.center}>

                <Text style={styles.texto}>
                    Precisamos da permissão para usar a câmera.
                </Text>

                <TouchableOpacity
                    style={styles.botao}
                    onPress={requestPermission}
                >

                    <Text style={styles.textoBotao}>
                        Permitir câmera
                    </Text>

                </TouchableOpacity>

            </View>
        );
    }


    // =====================================================
    // LER QR CODE
    // =====================================================

    function lerQRCode({ data }) {

        if (scaneado) {
            return;
        }

        setScaneado(true);

        console.log('QR Code lido:', data);

        // Tela que abriu o scanner
        const telaAnterior =
            route?.params?.telaAnterior || 'Entrada';

        console.log(
            'Voltando para:',
            telaAnterior
        );

        // Devolve o código para Entrada ou Saida
        navigation.navigate({
            name: telaAnterior,

            params: {
                codigoQR: data,
            },

            merge: true,
        });
    }


    // =====================================================
    // TELA
    // =====================================================

    return (
        <View style={styles.container}>

            <CameraView
                style={StyleSheet.absoluteFillObject}
                facing="back"

                barcodeScannerSettings={{
                    barcodeTypes: ['qr'],
                }}

                onBarcodeScanned={
                    scaneado
                        ? undefined
                        : lerQRCode
                }
            />


            {/* SOBREPOSIÇÃO */}

            <View style={styles.overlay}>

                <Text style={styles.titulo}>
                    Ler QR Code
                </Text>


                {/* ÁREA DO QR CODE */}

                <View style={styles.quadrado} />


                <Text style={styles.instrucao}>
                    Posicione o QR Code dentro do quadrado
                </Text>


                {/* BOTÃO NOVAMENTE */}

                {scaneado && (

                    <TouchableOpacity
                        style={styles.botao}
                        onPress={() => setScaneado(false)}
                    >

                        <Text style={styles.textoBotao}>
                            Escanear novamente
                        </Text>

                    </TouchableOpacity>

                )}

            </View>

        </View>
    );
}


// =====================================================
// ESTILOS
// =====================================================

const styles = StyleSheet.create({

    container: {
        flex: 1,
        backgroundColor: '#000',
    },

    center: {
        flex: 1,
        backgroundColor: '#111827',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 30,
    },

    texto: {
        color: '#fff',
        fontSize: 18,
        textAlign: 'center',
        marginBottom: 25,
    },

    overlay: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

    titulo: {
        color: '#fff',
        fontSize: 26,
        fontWeight: 'bold',
        marginBottom: 40,
    },

    quadrado: {
        width: 260,
        height: 260,
        borderWidth: 4,
        borderColor: '#fff',
        borderRadius: 20,
    },

    instrucao: {
        color: '#fff',
        fontSize: 16,
        marginTop: 30,
        textAlign: 'center',
    },

    botao: {
        backgroundColor: '#2563EB',
        paddingHorizontal: 25,
        paddingVertical: 15,
        borderRadius: 15,
        marginTop: 30,
    },

    textoBotao: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },

});