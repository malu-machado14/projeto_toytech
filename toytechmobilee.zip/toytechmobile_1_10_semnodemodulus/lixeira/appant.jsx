import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Login from '../screens/login';
import Dashboard from '../screens/dashboard';
import ListagemProd from '../screens/listagemprod';
import SoliEntrada from '../screens/solientrada';
import SoliSaida from '../screens/solisaida';


const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen
          name="Login"
          component={Login}
        />
        <Stack.Screen
          name="Dashboard"
          component={Dashboard}
        />

        <Stack.Screen
          name="Produtos"
          component={ListagemProd}
        />

        <Stack.Screen
          name="Entrada"
          component={SoliEntrada}
        />

        <Stack.Screen
          name="Saida"
          component={SoliSaida}
        />

        
      </Stack.Navigator>
    </NavigationContainer>
  );
}