import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import api from '../../src/services/api';

export default function Historico() {
  const [history, setHistory] = useState([]);

  const loadHistory = async () => {
    try {
      const response = await api.get('/history');
      
      // Ordena estritamente do ID mais recente para o mais antigo (ordem de chegada real)
      const formattedData = [...response.data].sort((a, b) => b.id - a.id);
      
      setHistory(formattedData);
    } catch (error) {
      console.log('Erro ao carregar histórico:', error);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Histórico Recente</Text>

      {history.length === 0 ? (
        <Text style={styles.emptyText}>Nenhuma movimentação registrada.</Text>
      ) : (
        <FlatList
          data={history}
          keyExtractor={(item, index) => (item.id ? item.id.toString() : index.toString())}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.lineItem}>
              <View style={styles.leftContent}>
                <Ionicons
                  name={item.type === 'Entrada' ? 'checkmark-circle' : 'close-circle'}
                  size={22}
                  color={item.type === 'Entrada' ? '#22C55E' : '#EF4444'}
                />
                <Text style={styles.productText} numberOfLines={1}>
                  {item.product}
                </Text>
                <Text
                  style={[
                    styles.typeTag,
                    { color: item.type === 'Entrada' ? '#22C55E' : '#EF4444' },
                  ]}
                >
                  ({item.type})
                </Text>
              </View>

              <Text style={styles.rightContent}>
                {item.quantity ? `${item.quantity} un • ` : ''}{item.date}
              </Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    marginTop: 25, 
    paddingHorizontal: 5 
  },
  title: { 
    color: '#fff', 
    fontSize: 20, 
    fontWeight: 'bold', 
    marginBottom: 15 
  },
  emptyText: {
    color: '#94A3B8',
    fontSize: 14,
    fontStyle: 'italic',
    marginTop: 5,
  },
  lineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1E293B',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  leftContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    marginRight: 10,
  },
  productText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flexShrink: 1,
  },
  typeTag: {
    fontSize: 13,
    fontWeight: 'bold',
  },
  rightContent: {
    color: '#94A3B8',
    fontSize: 13,
  },
});