const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');

//cria o app primeiro
const app = express();

//depois usa esses middlewares(serve pra  conectar diferentes aplicacoes)
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

//Conexao com o banco
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'Toytech_bd',
  waitForConnections: true,
  connectionLimit: 10,
});

//1-rota de login
app.post('/api/login', async (req, res) => {
  const { email, senha } = req.body;

  try {
    const [rows] = await db.query(
      'SELECT id, nome, cpf, email, telefone, cargo FROM funcionario WHERE email = ? AND senha = ?',
      [email, senha]
    );

    if (rows.length > 0) {
      res.json({
        success: true,
        user: rows[0]
      });
    } else {
      res.status(401).json({
        success: false,
        message: 'Credenciais inválidas.'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro interno no servidor.',
      error: error.message
    });
  }
});

//2-Rota de dashboard
app.get('/api/dashboard', async (req, res) => {
  try {
    const [[{ estoque }]] = await db.query('SELECT COALESCE(SUM(produto_quantidade), 0) as estoque FROM estoque');
    const [[{ totalEntradas }]] = await db.query('SELECT COUNT(*) as totalEntradas FROM item_solicitacao_entrada');
    const [[{ totalSaidas }]] = await db.query('SELECT COUNT(*) as totalSaidas FROM item_solicitacao_saida');
    const [recentActivities] = await db.query(`
      SELECT 
        e.estoque_id as id, 
        'Entrada' as type, 
        e.produto_quantidade as quantity, 
        p.nome as product 
      FROM estoque e
      JOIN produto p ON e.produto_id = p.id 
      ORDER BY e.estoque_id DESC LIMIT 5
    `);

    res.json({
      estoque: estoque || 0,
      totalEntradas: totalEntradas || 0,
      totalSaidas: totalSaidas || 0,
      recentActivities: recentActivities || [],
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const IP_SERVIDOR = '10.135.60.53';

//3-listar produtos
app.get('/api/produto', async (req, res) => {
  try {
    const [produtos] = await db.query(`
      SELECT 
        p.id, 
        CAST(p.id AS CHAR) AS code,
        p.nome AS name, 
        p.descricao AS category, 
        p.preco AS price, 
        p.imagem_nome AS image,              
        COALESCE(SUM(e.produto_quantidade), 0) AS stock
      FROM produto p
      LEFT JOIN estoque e ON p.id = e.produto_id
      GROUP BY p.id, p.nome, p.descricao, p.preco, p.imagem_nome
      ORDER BY p.nome ASC`
    );

    res.json(produtos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

//4-achar um produto especificio pelo id dele
app.get('/api/produto/:identifier', async (req, res) => {
  const { identifier } = req.params;
  try {
    const [rows] = await db.query(
      `SELECT 
        p.id, 
        CAST(p.id AS CHAR) AS code,
        p.nome AS name, 
        p.descricao AS category, 
        p.preco AS price, 
        p.imagem_nome AS image,
        COALESCE(SUM(e.produto_quantidade), 0) AS stock
      FROM produto p
      LEFT JOIN estoque e ON p.id = e.produto_id
      WHERE p.id = ?
      GROUP BY p.id, p.nome, p.descricao, p.preco, p.imagem_nome`,
      [identifier]
    );

    if (rows.length > 0) {
      res.json(rows[0]);
    } else {
      res.status(404).json({ message: 'Produto não encontrado' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 5. Entrada e saída de produtos
app.post('/api/stock/move', async (req, res) => {
  const { productId, type, quantity, funcionarioId = 1, fornecedorId, solicitadorId = 1, observacao } = req.body;
  const qtyNum = parseInt(quantity, 10);

  if (!productId || !type || isNaN(qtyNum) || qtyNum <= 0) {
    return res.status(400).json({ message: 'Dados inválidos.' });
  }

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    // 1- Busca dados do produto (incluindo o fornecedor_id real dele)
    const [[prod]] = await connection.query(
      'SELECT id, fornecedor_id FROM produto WHERE id = ?',
      [productId]
    );

    if (!prod) {
      await connection.rollback();
      return res.status(404).json({ message: 'Produto não encontrado.' });
    }

    // Usa o fornecedor recebido pelo App ou o fornecedor original do produto
    const realFornecedorId = fornecedorId || prod.fornecedor_id;

    // 2- Atualiza o estoque
    const sqlStock = type === 'Entrada'
      ? 'UPDATE estoque SET produto_quantidade = produto_quantidade + ? WHERE produto_id = ?'
      : 'UPDATE estoque SET produto_quantidade = produto_quantidade - ? WHERE produto_id = ? AND produto_quantidade >= ?';

    const params = type === 'Entrada' ? [qtyNum, productId] : [qtyNum, productId, qtyNum];
    const [result] = await connection.query(sqlStock, params);

    if (result.affectedRows === 0) {
      await connection.rollback();
      return res.status(400).json({ message: 'Estoque insuficiente ou produto não registrado no estoque.' });
    }

    // 3- Busca o estoque_id vinculado ao produto
    const [[est]] = await connection.query('SELECT estoque_id FROM estoque WHERE produto_id = ?', [productId]);
    const obsText = observacao || `${type} via App`;

    // 4- Grava no histórico de solicitação
    if (type === 'Entrada') {
      const [se] = await connection.query(
        'INSERT INTO solicitacao_entrada (data_solicitacao_entrada, funcionario_id, fornecedor_id, observacao) VALUES (NOW(), ?, ?, ?)',
        [funcionarioId, realFornecedorId, obsText]
      );
      await connection.query(
        'INSERT INTO item_solicitacao_entrada (id_operacao_e, estoque_id) VALUES (?, ?)',
        [se.insertId, est.estoque_id]
      );
    } else {
      const [ss] = await connection.query(
        'INSERT INTO solicitacao_saida (data_solicitacao_saida, funcionario_id, solicitador_id, observacao) VALUES (NOW(), ?, ?, ?)',
        [funcionarioId, solicitadorId, obsText]
      );
      await connection.query(
        'INSERT INTO item_solicitacao_saida (id_operacao_s, estoque_id) VALUES (?, ?)',
        [ss.insertId, est.estoque_id]
      );
    }

    await connection.commit();
    return res.json({ success: true, message: `Movimentação de ${type.toLowerCase()} registrada com sucesso!` });

  } catch (error) {
    await connection.rollback();
    console.error('Erro MySQL:', error);
    return res.status(500).json({ message: `Erro no banco: ${error.sqlMessage || error.message}` });
  } finally {
    connection.release();
  }
});


//6-historico das solicitacoes de entrada
app.get(['/api/solientrada'], async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        se.id_operacao_e,
        se.data_solicitacao_entrada,
        se.funcionario_id,
        se.fornecedor_id,
        se.observacao,
        ise.estoque_id
      FROM solicitacao_entrada se
      LEFT JOIN item_solicitacao_entrada ise ON se.id_operacao_e = ise.id_operacao_e
      ORDER BY se.id_operacao_e DESC
    `);
    return res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar entradas:', error);
    return res.status(500).json({ message: 'Erro ao consultar a base de dados.' });
  }
});

//7-historico das solicitacoes de saida
app.get(['/api/solisaida'], async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        ss.id_operacao_s,
        ss.data_solicitacao_saida,
        ss.funcionario_id,
        ss.solicitador_id,
        ss.observacao,
        iss.estoque_id
      FROM solicitacao_saida ss
      LEFT JOIN item_solicitacao_saida iss ON ss.id_operacao_s = iss.id_operacao_s
      ORDER BY ss.id_operacao_s DESC
    `);
    return res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar saídas:', error);
    return res.status(500).json({ message: 'Erro ao consultar a base de dados.' });
  }
});

//Historico- entrada e saida de produtos
app.get('/api/historico', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        CONCAT('E-', se.id_operacao_e) AS id,
        'Entrada' AS type,
        p.nome AS product,
        DATE_FORMAT(se.data_solicitacao_entrada, '%d/%m/%Y') AS date,
        DATE_FORMAT(se.data_solicitacao_entrada, '%H:%i') AS hour
      FROM solicitacao_entrada se
      JOIN item_solicitacao_entrada ise ON se.id_operacao_e = ise.id_operacao_e
      JOIN estoque e ON ise.estoque_id = e.estoque_id
      JOIN produto p ON e.produto_id = p.id

      UNION ALL

      SELECT 
        CONCAT('S-', ss.id_operacao_s) AS id,
        'Saída' AS type,
        p.nome AS product,
        DATE_FORMAT(ss.data_solicitacao_saida, '%d/%m/%Y') AS date,
        DATE_FORMAT(ss.data_solicitacao_saida, '%H:%i') AS hour
      FROM solicitacao_saida ss
      JOIN item_solicitacao_saida iss ON ss.id_operacao_s = iss.id_operacao_s
      JOIN estoque e ON iss.estoque_id = e.estoque_id
      JOIN produto p ON e.produto_id = p.id

      ORDER BY id DESC
    `);

    res.json(rows);
  } catch (error) {
    console.error('Erro ao buscar histórico:', error);
    res.status(500).json({ message: 'Erro ao carregar histórico.' });
  }
});

//PORTA PARA O SERVIDOR RODA
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));