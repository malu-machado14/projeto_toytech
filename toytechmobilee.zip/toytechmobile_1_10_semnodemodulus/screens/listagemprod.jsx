//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DO PROJETO
import React, { useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import api from '../src/services/api';

import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function ListagemProd({ navigation }) {
  const [search, setSearch] = useState('');
  const [produto, setProduto] = useState([]);

  //imagens dos prdoutos
  const IMAGENS_LOCAIS = {
    'download (3).png': require('../assets/imgs/buzzlaitir.png'),
    'download (2).png': require('../assets/imgs/cubumagicu.jpg'),
    'download (1).png': require('../assets/imgs/hotiuius.jpg'),
    'download (4).png': require('../assets/imgs/baiblaide.jpg'),
  };

  //imagem padrao, caso a imagem que voce procura nao seja encontrada
  const IMAGEM_PADRAO = require('../assets/imgs/icon.png');

  const loadProduto = async () => {
    try {
      const response = await api.get('/produto');
      setProduto(response.data);
    } catch (error) {
      console.log('Erro ao buscar produtos:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadProduto();
    }, [])
  );

  {/*PRODUTOS EM ORDEM */}
  const filteredproduto = produto.filter(
    (item) =>
      item.name?.toLowerCase().includes(search.toLowerCase()) ||
      item.category?.toLowerCase().includes(search.toLowerCase()) ||
      item.code?.toLowerCase().includes(search.toLowerCase())
  );

  {/*HEADER */}
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.backButton}
          >

            {/*PRODUTOS */}
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.title}>Produtos</Text>
          <Text style={styles.subtitle}>Consulte os produtos cadastrados</Text>
        </View>

        {/*BOTAO PARA FILTRAR */}
        <TouchableOpacity style={styles.filterButton}>
          <Ionicons name="options-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </View>


      {/*NAVEGACAO ENTRE OS PRODUTOS */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={22} color="#94A3B8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Pesquisar produtos..."
          placeholderTextColor="#94A3B8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/*BOTOES - ENTRADA E SAIDA */}
      <FlatList
        data={filteredproduto}
        style={{ flex: 1 }}
        keyExtractor={(item) => item.id.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
        renderItem={({ item }) => (
          //BOTOES PARA DIRECIONAR VOCE AS TELAS QUE PROCURA-ENTRADA OU SAIDA DOS PRDOUTOS
          <TouchableOpacity
            style={styles.card}
            activeOpacity={0.9}
            onPress={() => {
              Alert.alert('Escolha uma opção', 'O que deseja fazer?', [
                {
                  text: 'Entrada',
                  onPress: () => navigation.navigate('Entrada', { produto: item }),
                },
                {
                  text: 'Saída',
                  onPress: () => navigation.navigate('Saida', { produto: item }),
                },
                {
                  text: 'Cancelar',
                  style: 'cancel',
                },
              ]);
            }}
          >
            {/* Se a imagem for um url, ela aparece, mas se nao, é a imagem padrao que aparece */}
            <Image
              source={
                item.image && IMAGENS_LOCAIS[item.image]
                  ? IMAGENS_LOCAIS[item.image]
                  : IMAGEM_PADRAO
              }
              style={styles.image}
              resizeMode="cover"
            />

            {/*NOME E CATEGORIA DO PRODUTO */}
            <View style={styles.content}>
              <View style={styles.topRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{item.name}</Text>
                  <Text style={styles.category}>{item.category || 'Sem descrição'}</Text>
                </View>

                {/*PRODUTO COM O ESTOQUE ALTO E BAIXO */}
                <View
                  style={[
                    styles.stockBadge,
                    {
                      backgroundColor: Number(item.stock) <= 5 ? '#7F1D1D' : '#14532D',
                    },
                  ]}
                >
                  <Text style={styles.stockText}>{item.stock}</Text>
                </View>
              </View>
              
              {/*O PRODUTO ESTA NO ESTOQUE*/}
              <View style={styles.infoRow}>
                <View style={styles.infoCard}>
                  <Ionicons name="cube-outline" size={18} color="#3B82F6" />
                  <Text style={styles.infoText}>Estoque</Text>
                </View>
                
                {/*CODIGO */}
                <View style={styles.infoCard}>
                  <Ionicons name="barcode-outline" size={18} color="#22C55E" />
                  <Text style={styles.infoText}>{item.code || `ID: ${item.id}`}</Text>
                </View>
              </View>
              
              {/*PRECO */}
              <View style={styles.bottomRow}>
                <Text style={styles.price}>
                  R$ {Number(item.price || 0).toFixed(2)}
                </Text>
                
                {/*ESTOQUE DO PRODUTO */}
                <Text
                  style={[
                    styles.stockStatus,
                    {
                      color: Number(item.stock) <= 5 ? '#FCA5A5' : '#86EFAC',
                    },
                  ]}
                >
                  {Number(item.stock) <= 5 ? 'Estoque baixo' : 'Disponível'}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

{/*ESTILO DA INTERFACE */}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingHorizontal: 20,
  },
  backButton: {
    marginBottom: 10,
  },
  header: {
    marginTop: 55,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },
  title: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
  },
  subtitle: {
    color: '#94A3B8',
    marginTop: 5,
    fontSize: 15,
  },
  filterButton: {
    width: 52,
    height: 52,
    backgroundColor: '#1E293B',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    backgroundColor: '#1E293B',
    height: 62,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    marginBottom: 25,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    color: '#fff',
    fontSize: 16,
  },
  card: {
    backgroundColor: '#1E293B',
    borderRadius: 28,
    overflow: 'hidden',
    marginBottom: 22,
  },
  image: {
    width: '100%',
    height: 220,
  },
  content: {
    padding: 20,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  name: {
    color: '#fff',
    fontSize: 21,
    fontWeight: 'bold',
  },
  category: {
    color: '#94A3B8',
    marginTop: 6,
    fontSize: 15,
  },
  stockBadge: {
    minWidth: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  stockText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  infoRow: {
    flexDirection: 'row',
    marginTop: 18,
    gap: 12,
  },
  infoCard: {
    backgroundColor: '#0F172A',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoText: {
    color: '#CBD5E1',
    marginLeft: 8,
    fontSize: 13,
  },
  bottomRow: {
    marginTop: 22,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    color: '#3B82F6',
    fontSize: 26,
    fontWeight: 'bold',
  },
  stockStatus: {
    fontSize: 14,
    fontWeight: '600',
  },
  
});