//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DO PROJETO
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  Image,
  Alert
} from 'react-native';
import api from '../src/services/api';

export default function Login({ navigation }) {
  const [user, setUser] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = async () => {
    if (!user || !senha) {
      Alert.alert('Atenção', 'Preencha todos os campos.');
      return;
    }

    try {
      const response = await api.post('/login', { email: user, senha });
      if (response.data.success) {
        navigation.navigate('App');
      }
    } catch (error) {
      Alert.alert('Erro', error.response?.data?.message || 'Falha ao conectar ao servidor.');
    }
  };

  {/*IMAGEM DE FUNDO */}
  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.background}
      resizeMode="cover"
    >
      {/*LOGO DA NOSSA EMPRESA */}
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Image
            source={require('../assets/imgs/logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
          {/*TITULO E SUBTITULO DO LOGIN */}
          <Text style={styles.titulo}>Sistema de estoque</Text>
          <Text style={styles.subtitulo}>Faça seu login abaixo:</Text>

          {/*CAMPOS PRA PREENCHER NO LOGIN */}
          <TextInput
            placeholder="E-mail / Usuário"
            placeholderTextColor="#9CA3AF"
            style={styles.input}
            value={user}
            onChangeText={setUser}
            autoCapitalize="none"
          />

          <TextInput
            placeholder="Senha"
            placeholderTextColor="#9CA3AF"
            style={styles.input}
            value={senha}
            onChangeText={setSenha}
            secureTextEntry
          />

          {/*BOTAO PRA ENTRAR */}
          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Entrar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

{/*ESTILO DA INTERFACE */}
const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.75)', 
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: '#0F172A',
    borderRadius: 16,
    padding: 25,
    alignItems: 'stretch',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  logo: {
    width: 120,
    height: 120,
    alignSelf: 'center',
    marginBottom: 15,
  },
  titulo: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 5,
  },
  subtitulo: {
    color: '#94A3B8',
    textAlign: 'center',
    marginBottom: 25,
    fontSize: 14,
  },
  input: {
    backgroundColor: '#1E293B',
    height: 55,
    borderRadius: 12,
    paddingHorizontal: 15,
    color: '#FFF',
    marginBottom: 15,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#2563EB',
    height: 55,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});