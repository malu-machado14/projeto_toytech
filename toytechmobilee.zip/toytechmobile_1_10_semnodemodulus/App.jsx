import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

//importacao das telas
import Login from './screens/login';
import Dashboard from './screens/dashboard';
import ListagemProd from './screens/listagemprod';
import SoliEntrada from './screens/solientrada';
import SoliSaida from './screens/solisaida';
import Historico from './screens/historico';

//NAVEGADORES
const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

//NAVEGAR PELAS ABAS
function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: '#0F172A',
          borderTopWidth: 0,
          height: 65,
        },

        //ICONE PRAS ABAS
        tabBarIcon: ({ focused }) => {
          let iconName;
          if (route.name === 'Dashboard') iconName = focused ? 'home' : 'home-outline';
          else if (route.name === 'Produtos') iconName = focused ? 'cube' : 'cube-outline';
          else if (route.name === 'Entrada') iconName = focused ? 'arrow-down-circle' : 'arrow-down-circle-outline';
          else if (route.name === 'Saida') iconName = focused ? 'arrow-up-circle' : 'arrow-up-circle-outline';
          else if (route.name === 'Historico') iconName = focused ? 'time' : 'time-outline';

          return <Ionicons name={iconName} size={24} color={focused ? '#3B82F6' : '#94A3B8'} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Produtos" component={ListagemProd} />
      <Tab.Screen name="Entrada" component={SoliEntrada} />
      <Tab.Screen name="Saida" component={SoliSaida} />
      <Tab.Screen name="Historico" component={Historico} />
    </Tab.Navigator>
  );
}

//Login como a primeira tela do sistema
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="App" component={TabNavigator} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}