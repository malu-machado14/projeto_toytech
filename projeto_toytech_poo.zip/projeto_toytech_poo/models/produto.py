#imports
from core.crud import Crud
from core.conexao import Database
from core.validar import Validador

#classe que representa o produto
class Produto(Crud):
    table = "produto"
    #lista de campos da tabela
    fields = [
        "nome",
        "descricao",
        "categoria",
        "fornecedor",
        "quantidade",
        "estoque_minimo",
        "preco",
    ]

    #metodo para inicializar o objeto com valores iniciais
    def __init__(self, nome, descricao, categoria, unidade_medida,
                 quantidade, estoque_minimo, preco):
        #atribui os valores aos objetos
        self.nome = nome
        self.descricao = descricao
        self.categoria = categoria
        self.unidade_medida = unidade_medida
        self.quantidade = quantidade
        self.estoque_minimo = estoque_minimo
        self.preco = preco

    #valida os dados do produto
    def validate(self):
        #lista de possiveis erros
        erros = [
         Validador.required(self.nome, "nome"),
         Validador.non_negative(self.descricao, "descrição"),
         Validador.non_negative(self.categoria, "categoria"),
         Validador.non_negative(self.unidade_medida, "unidade de medida"),
         Validador.non_negative(self.quantidade, "quantidade"),
         Validador.non_negative(self.estoque_minimo, "estoque mínimo"),
         Validador.non_negative(self.preco, "preço")
        ]
        #retorna os erros
        return [erro for erro in erros if erro]

    #retorna produtos com estoque baixo
    @classmethod
    def low_stock(cls):
        #conexao com o banco
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM produto WHERE quantidade <= estoque_minimo ORDER BY nome"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    #metodo para atualizar a quantidade de produtos
    @classmethod
    def update_quantity(cls, id, nova_quantidade, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE produto SET quantidade = %s WHERE id = %s"
            cursor.execute(sql, (nova_quantidade, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    #metodo para ver se possui registros relacionados
    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE produto_id = %s",
                "SELECT COUNT(*) FROM pedido_movimentacao WHERE produto_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    #metodo para deletar um produto
    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Produto não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o produto porque ele possui solicitações ou movimentações vinculadas ou pendentes.")
        cls.delete(id)
