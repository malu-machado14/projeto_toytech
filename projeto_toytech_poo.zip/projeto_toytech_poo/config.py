DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "Toytech_bd"
}
